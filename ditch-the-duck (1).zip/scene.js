// ═══════════════════════════════════════════════════════════════
// DITCH THE DUCK — Full Game Engine with Level/Coin/Heart System
// ═══════════════════════════════════════════════════════════════

// ── Duck Image Helper ────────────────────────────────────────
function getDuckImageURL() {
  // Try window.UPLOADED_IMAGES first — look for the duck (06-54-48 or latest)
  if (window.UPLOADED_IMAGES && window.UPLOADED_IMAGES.length) {
    for (var i = 0; i < window.UPLOADED_IMAGES.length; i++) {
      var u = window.UPLOADED_IMAGES[i];
      if (u.name && u.name.indexOf('06-54-48') >= 0) return u.dataUrl || ('assets/' + u.name);
    }
    // Fallback to any pasted image
    for (var i = 0; i < window.UPLOADED_IMAGES.length; i++) {
      var u = window.UPLOADED_IMAGES[i];
      if (u.name && u.type && u.type.indexOf('image') >= 0) return u.dataUrl || ('assets/' + u.name);
    }
  }
  return 'assets/pasted-image-2026-03-28T07-18-06.png';
}
// Fix all duck images once the page is ready
function fixAllDuckImages() {
  var url = getDuckImageURL();
  document.querySelectorAll('.duck-img, #duckImg').forEach(function(img) {
    if (!img.complete || img.naturalWidth === 0) img.src = url;
  });
}
setTimeout(fixAllDuckImages, 100);
setTimeout(fixAllDuckImages, 500);
setTimeout(fixAllDuckImages, 1500);

// ── Question Database (50 questions) ─────────────────────────
const QUESTIONS = [
  // ── Batch 1 (1–50) ──────────────────────────────────────────
  { q: "Why is my cat...", answers: ["Staring at a wall", "Writing a book", "Wearing my hat", "Speaking French"], correct: 0 },
  { q: "Is it legal to...", answers: ["Own a flamethrower", "Eat a cloud", "Marry a toaster", "Sleep on the moon"], correct: 0 },
  { q: "Can I give my dog...", answers: ["Blueberries", "A credit card", "A cell phone", "Car keys"], correct: 0 },
  { q: "Why do I always...", answers: ["Feel tired", "See ninjas", "Smell like pancakes", "Hear bagpipes"], correct: 0 },
  { q: "Does the moon...", answers: ["Rotate", "Have a secret base", "Taste like cheese", "Wear a wig"], correct: 0 },
  { q: "How to tell if I am...", answers: ["In love", "A hologram", "A secret agent", "Made of pasta"], correct: 0 },
  { q: "Why is there a...", answers: ["Dead pixel", "Duck in my fridge", "Glitch in the matrix", "Ghost in my soup"], correct: 0 },
  { q: "Is it normal to...", answers: ["Talk to yourself", "Eat raw lemons", "Run at 3 AM", "Hate the sun"], correct: 0 },
  { q: "Why are my feet...", answers: ["Always cold", "Turning green", "Growing wings", "Smelling like roses"], correct: 0 },
  { q: "Can birds fly in...", answers: ["Rain", "Space", "A vacuum", "My dreams"], correct: 0 },
  { q: "Why does my dog...", answers: ["Stare at me", "Want to be a cat", "Hate the mailman", "Play the drums"], correct: 0 },
  { q: "Is it safe to...", answers: ["Eat expired eggs", "Pet a shark", "Sleep in a tree", "Breathe on Mars"], correct: 0 },
  { q: "Why do humans...", answers: ["Have eyebrows", "Live on Earth", "Eat food", "Sleep at night"], correct: 0 },
  { q: "Can cats see...", answers: ["Ghosts", "The future", "Through walls", "My thoughts"], correct: 0 },
  { q: "Why is the sky...", answers: ["Blue", "Falling", "Made of glass", "Purple at night"], correct: 0 },
  { q: "How to know if...", answers: ["My house is haunted", "I am a robot", "Cats like me", "I can fly"], correct: 0 },
  { q: "Why do I smell...", answers: ["Burnt toast", "Like a wet dog", "Money", "Old books"], correct: 0 },
  { q: "Can you survive...", answers: ["A lightning strike", "On only pizza", "Without a brain", "A black hole"], correct: 0 },
  { q: "Why do cows...", answers: ["Moo", "Wear bells", "Stand in the rain", "Eat grass"], correct: 0 },
  { q: "Is it bad to...", answers: ["Crack your knuckles", "Drink water", "Breathe air", "Sleep 8 hours"], correct: 0 },
  { q: "Why does my eye...", answers: ["Twitch", "See the future", "Glow in the dark", "Change color"], correct: 0 },
  { q: "Can ants survive...", answers: ["A microwave", "A fall from a plane", "Underwater", "On Mars"], correct: 0 },
  { q: "Why do we...", answers: ["Yawn", "Have 10 toes", "Like music", "Dream"], correct: 0 },
  { q: "Is it illegal to...", answers: ["Drive barefoot", "Eat pizza with a fork", "Sleep in your car", "Sing in the shower"], correct: 0 },
  { q: "Why is my hair...", answers: ["Falling out", "Turning blue", "So soft", "Growing backwards"], correct: 0 },
  { q: "Can a turtle...", answers: ["Breathe through its butt", "Fly a plane", "Live forever", "Talk back"], correct: 0 },
  { q: "Why do sharks...", answers: ["Attack humans", "Never sleep", "Have sharp teeth", "Like blood"], correct: 0 },
  { q: "Is the earth...", answers: ["Flat", "Hollow", "A giant turtle", "Made of gold"], correct: 0 },
  { q: "Why do I have...", answers: ["Hiccups", "Wings", "11 fingers", "No shadow"], correct: 0 },
  { q: "Can plants...", answers: ["Feel pain", "Hear music", "Walk at night", "Talk to me"], correct: 0 },
  { q: "Why is bacon...", answers: ["Called bacon", "So salty", "Red", "Made of pigs"], correct: 0 },
  { q: "Is it possible to...", answers: ["Sneeze with eyes open", "Touch the sun", "Live without sleep", "Fly"], correct: 0 },
  { q: "Why do bees...", answers: ["Die after stinging", "Make honey", "Buzz", "Dance"], correct: 0 },
  { q: "Can you get...", answers: ["Pregnant from a kiss", "A tan from a lightbulb", "Sick from cold air", "Rich fast"], correct: 0 },
  { q: "Why do I cry...", answers: ["When I peel onions", "For no reason", "When I'm happy", "At movies"], correct: 0 },
  { q: "Is it true that...", answers: ["Glass is a liquid", "Bats are blind", "Humans use 10% brain", "Bulls hate red"], correct: 0 },
  { q: "Why does fruit...", answers: ["Attract flies", "Turn brown", "Have seeds", "Taste sweet"], correct: 0 },
  { q: "Can I wash my...", answers: ["Cat with dish soap", "Hair with beer", "Car with vinegar", "Money"], correct: 0 },
  { q: "Why is my nose...", answers: ["Always stuffy", "So big", "Running", "Bleeding"], correct: 0 },
  { q: "Is it normal for...", answers: ["Babies to stare", "Cats to knead", "Dogs to howl", "Birds to sing"], correct: 0 },
  { q: "Why do people...", answers: ["Lie", "Ghost people", "Wear shoes", "Like spicy food"], correct: 0 },
  { q: "Can snakes...", answers: ["Blink", "Hear", "Fly", "Jump"], correct: 0 },
  { q: "Why is it called...", answers: ["A building", "A sandwich", "A pineapple", "A boxing ring"], correct: 0 },
  { q: "Is it okay to...", answers: ["Cry", "Eat breakfast for dinner", "Be alone", "Skip a day"], correct: 0 },
  { q: "Why do mirrors...", answers: ["Flip left and right", "Show ghosts", "Break", "Look silver"], correct: 0 },
  { q: "Can I bring a...", answers: ["Turtle on a plane", "Sword to school", "Dog to a wedding", "Cat to work"], correct: 0 },
  { q: "Why do we have...", answers: ["Wisdom teeth", "Names", "Seasons", "Dreams"], correct: 0 },
  { q: "Is it weird to...", answers: ["Like the smell of gas", "Eat ice", "Sleep with socks", "Talk to plants"], correct: 0 },
  { q: "Why do spiders...", answers: ["Have 8 legs", "Make webs", "Eat their mates", "Hide"], correct: 0 },
  { q: "Can you grow...", answers: ["Taller after 20", "A tree in your stomach", "Money", "Wings"], correct: 0 },

  // ── Batch 2 (51–100) ─────────────────────────────────────────
  { q: "Is it illegal to...", answers: ["Eat an orange in a bathtub", "Walk a dog", "Buy milk", "Wear a blue shirt"], correct: 0 },
  { q: "Why do I always...", answers: ["Wake up at 3am", "Forget my name", "See a giant duck", "Smell fresh rain"], correct: 0 },
  { q: "Can you get...", answers: ["A tan from a computer", "Sick from a ghost", "Pregnant from a pool", "A cold from ice"], correct: 0 },
  { q: "Why is my dog...", answers: ["Eating grass", "Trying to drive", "Staring at the ceiling", "Barking at nothing"], correct: 0 },
  { q: "Does the sun...", answers: ["Make a noise", "Have a face", "Sleep at night", "Rotate"], correct: 0 },
  { q: "How to tell if...", answers: ["My cat is plotting to kill me", "I am a wizard", "My house is on Mars", "I am dreaming"], correct: 0 },
  { q: "Why do I smell...", answers: ["Cucumbers", "Old pennies", "Wet pavement", "Burnt hair"], correct: 0 },
  { q: "Can humans survive...", answers: ["Without a gall bladder", "On the moon", "Eating only grass", "In a vacuum"], correct: 0 },
  { q: "Why do cats...", answers: ["Hate water", "Love boxes", "Meow at humans", "Sleep 16 hours"], correct: 0 },
  { q: "Is it bad to...", answers: ["Swallow gum", "Drink orange juice", "Sleep with a fan on", "Eat apple seeds"], correct: 0 },
  { q: "Why does my laptop...", answers: ["Sound like a plane", "Smell like popcorn", "Glow red", "Get so hot"], correct: 0 },
  { q: "Can ants...", answers: ["Carry 50 times their weight", "Talk to bees", "Swim in milk", "Live in space"], correct: 0 },
  { q: "Why do we...", answers: ["Get goosebumps", "Have fingernails", "Sneeze looking at sun", "Cry"], correct: 0 },
  { q: "Is it illegal to...", answers: ["Record a movie", "Whistle underwater", "Own a pet rock", "Walk backwards"], correct: 0 },
  { q: "Why is my skin...", answers: ["Peeling", "Turning orange", "So itchy", "Always dry"], correct: 0 },
  { q: "Can a bird...", answers: ["Fly backwards", "Talk to dogs", "Live underwater", "See ghosts"], correct: 0 },
  { q: "Why do sharks...", answers: ["Have two rows of teeth", "Hate dolphins", "Swim in circles", "Attack surfers"], correct: 0 },
  { q: "Is the ocean...", answers: ["Getting deeper", "Made of tears", "Full of gold", "Drying up"], correct: 0 },
  { q: "Why do I have...", answers: ["Cold hands", "Three ears", "A tail", "Green eyes"], correct: 0 },
  { q: "Can trees...", answers: ["Talk to each other", "Scream", "Grow in space", "Feel heat"], correct: 0 },
  { q: "Why is cheese...", answers: ["So addictive", "Yellow", "Smelly", "Full of holes"], correct: 0 },
  { q: "Is it possible to...", answers: ["Die of a broken heart", "Jump over a house", "Breathe underwater", "See air"], correct: 0 },
  { q: "Why do bees...", answers: ["Make hexagons", "Buzz", "Like the color blue", "Die in winter"], correct: 0 },
  { q: "Can you catch...", answers: ["A cold from being cold", "A star", "A ghost in a jar", "A feeling"], correct: 0 },
  { q: "Why do I cry...", answers: ["When I laugh", "When I see a baby", "For no reason", "At night"], correct: 0 },
  { q: "Is it true that...", answers: ["Your ears never stop growing", "Gold is edible", "Money is dirty", "Pigs can fly"], correct: 0 },
  { q: "Why does bread...", answers: ["Rise", "Turn into toast", "Have holes", "Get moldy"], correct: 0 },
  { q: "Can I use...", answers: ["Honey as a bandage", "A sock as a filter", "Salt to melt ice", "Juice as fuel"], correct: 0 },
  { q: "Why is my tongue...", answers: ["White", "Tied", "Always burnt", "Numb"], correct: 0 },
  { q: "Is it normal for...", answers: ["Cats to have the zoomies", "Dogs to eat poop", "Birds to fall", "Humans to yawn"], correct: 0 },
  { q: "Why do people...", answers: ["Ghost after a first date", "Hate Mondays", "Collect stamps", "Fear spiders"], correct: 0 },
  { q: "Can spiders...", answers: ["Hear with their legs", "Fly", "Live in water", "See in the dark"], correct: 0 },
  { q: "Why is it called...", answers: ["A deadbolt", "Ketchup", "A dashboard", "A butterfly"], correct: 0 },
  { q: "Is it okay to...", answers: ["Sleep all day", "Eat raw cookie dough", "Talk to yourself", "Be sad"], correct: 0 },
  { q: "Why do bubbles...", answers: ["Pop", "Stay round", "Have colors", "Float"], correct: 0 },
  { q: "Can I take a...", answers: ["Goat on a bus", "Sword on a train", "Dog to a theater", "Duck to a wedding"], correct: 0 },
  { q: "Why do we have...", answers: ["Birthmarks", "Nightmares", "Eyelashes", "Names"], correct: 0 },
  { q: "Is it weird to...", answers: ["Enjoy the smell of a garage", "Lick a battery", "Sleep without a pillow", "Eat ice"], correct: 0 },
  { q: "Why do snakes...", answers: ["Shed their skin", "Hiss", "Have forked tongues", "Wink"], correct: 0 },
  { q: "Can you grow...", answers: ["A plant in your lung", "Money on trees", "Taller in space", "Wings"], correct: 0 },
  { q: "Why is my car...", answers: ["Shaking", "Making a whistling noise", "Leaking green fluid", "So slow"], correct: 0 },
  { q: "Is it legal to...", answers: ["Name your kid Batman", "Eat a swan", "Keep a tiger", "Drive a tank"], correct: 0 },
  { q: "Why do I feel...", answers: ["Like someone is watching me", "Dizzy when standing", "Heavy", "Invisible"], correct: 0 },
  { q: "Can cats eat...", answers: ["Chocolate", "Marshmallows", "Cheese", "Tuna every day"], correct: 0 },
  { q: "Why is the desert...", answers: ["Cold at night", "Full of sand", "Hot", "So quiet"], correct: 0 },
  { q: "Is it true that...", answers: ["Lightning never strikes twice", "Blood is blue", "An apple a day works", "Bats are mice"], correct: 0 },
  { q: "Why do I dream...", answers: ["About falling", "In black and white", "About teeth falling out", "About water"], correct: 0 },
  { q: "Can you survive...", answers: ["A fall from 30,000 feet", "On Mars", "Without air for 10 min", "A shark bite"], correct: 0 },
  { q: "Why do we say...", answers: ["Bless you", "Break a leg", "Piece of cake", "Holy cow"], correct: 0 },
  { q: "Is it normal to...", answers: ["Have a favorite side of bed", "Hate the sound of chewing", "Talk to your car", "Sleepwalk"], correct: 0 },

  // ── Batch 3 (101–150) ────────────────────────────────────────
  { q: "Why is there a...", answers: ["Hole in my cracker", "Ghost in my selfie", "Bird in my house", "Shark in my pool"], correct: 0 },
  { q: "Is it illegal to...", answers: ["Forget to pay taxes", "Own a blue lobster", "Grow your own hair", "Build a sandcastle"], correct: 0 },
  { q: "Why do I always...", answers: ["Lose my remote", "Feel like a failure", "Smell burning rubber", "See shadow people"], correct: 0 },
  { q: "Can you get...", answers: ["High on life", "A virus from an image", "Pregnant from a hot tub", "Sick from a frog"], correct: 0 },
  { q: "Why is my dog...", answers: ["Sleeping like a human", "Wearing a tuxedo", "Digging to China", "Barking at the wind"], correct: 0 },
  { q: "Does the moon...", answers: ["Affect my mood", "Have a dark side", "Look like a banana", "Fall down"], correct: 0 },
  { q: "How to tell if...", answers: ["Your microwave is listening", "You are a psychic", "Your boss is a robot", "You can breathe fire"], correct: 0 },
  { q: "Why do I smell...", answers: ["Rotten eggs", "Fresh laundry", "Wood smoke", "Chlorine"], correct: 0 },
  { q: "Can humans survive...", answers: ["A week without water", "In a giant bubble", "On only potatoes", "Under a waterfall"], correct: 0 },
  { q: "Why do cats...", answers: ["Chatter at birds", "Sleep on your chest", "Bring you dead mice", "Have sandpaper tongues"], correct: 0 },
  { q: "Is it bad to...", answers: ["Sleep with wet hair", "Eat at midnight", "Hold in a sneeze", "Talk to ghosts"], correct: 0 },
  { q: "Why does my laptop...", answers: ["Make a clicking noise", "Show a blue screen", "Keep restarting", "Smell like ozone"], correct: 0 },
  { q: "Can ants...", answers: ["Survive a fall from space", "Recognize their owners", "Learn tricks", "Feel sadness"], correct: 0 },
  { q: "Why do we...", answers: ["Have pinky toes", "Get brain freeze", "Love the smell of rain", "Laugh"], correct: 0 },
  { q: "Is it illegal to...", answers: ["Harvest rainwater", "Name a pig Napoleon", "Wear camouflage", "Use a fake name"], correct: 0 },
  { q: "Why is my skin...", answers: ["Turning blue", "So oily", "Breaking out", "Glowing"], correct: 0 },
  { q: "Can a bird...", answers: ["Sleep while flying", "Swim underwater", "Recognize faces", "Grow teeth"], correct: 0 },
  { q: "Why do sharks...", answers: ["Sink if they stop moving", "Love blood", "Have no bones", "Glow"], correct: 0 },
  { q: "Is the ocean...", answers: ["Full of plastic", "Boiling", "Made of salt", "Hiding aliens"], correct: 0 },
  { q: "Why do I have...", answers: ["Circles under my eyes", "Two left feet", "A metallic taste", "Itchy ears"], correct: 0 },
  { q: "Can trees...", answers: ["Live for 5000 years", "Bleed", "Walk", "Grow upside down"], correct: 0 },
  { q: "Why is cheese...", answers: ["So expensive", "A solid", "Made of mold", "Orange in America"], correct: 0 },
  { q: "Is it possible to...", answers: ["See your own soul", "Touch a rainbow", "Live on Mars", "Breathe fire"], correct: 0 },
  { q: "Why do bees...", answers: ["Vibrate", "Hate the rain", "Make propolis", "Sleep in flowers"], correct: 0 },
  { q: "Can you catch...", answers: ["A break", "A cold from a fan", "A fly with chopsticks", "A falling star"], correct: 0 },
  { q: "Why do I cry...", answers: ["When I see a sunset", "After I eat", "When I'm angry", "In my sleep"], correct: 0 },
  { q: "Is it true that...", answers: ["We eat 8 spiders a year", "Ducks' quacks don't echo", "Dogs see in 3D", "Space is cold"], correct: 0 },
  { q: "Why does bread...", answers: ["Smell so good", "Get hard", "Have a crust", "Float"], correct: 0 },
  { q: "Can I use...", answers: ["A banana peel to shine shoes", "Vodka to clean", "Sugar as a fuel", "Coffee to dye hair"], correct: 0 },
  { q: "Why is my tongue...", answers: ["Yellow", "Sore on the sides", "Swollen", "Purple"], correct: 0 },
  { q: "Is it normal for...", answers: ["Dogs to lean on you", "Cats to stare at doors", "Birds to scream", "Fish to sleep"], correct: 0 },
  { q: "Why do people...", answers: ["Buy toilet paper", "Hate the word moist", "Like ASMR", "Fear the dark"], correct: 0 },
  { q: "Can spiders...", answers: ["Change color", "Swim", "Remember you", "Feel pain"], correct: 0 },
  { q: "Why is it called...", answers: ["A flea market", "Window shopping", "A deadbeat", "A hard drive"], correct: 0 },
  { q: "Is it okay to...", answers: ["Talk to yourself", "Eat pizza for breakfast", "Be a loner", "Skip a shower"], correct: 0 },
  { q: "Why do bubbles...", answers: ["Join together", "Look like rainbows", "Go up", "Freeze"], correct: 0 },
  { q: "Can I take a...", answers: ["Penguin on a plane", "Tiger on a leash", "Sword to a park", "Llama to church"], correct: 0 },
  { q: "Why do we have...", answers: ["Eyebrows", "Belly buttons", "Fingernails", "Bad breath"], correct: 0 },
  { q: "Is it weird to...", answers: ["Like the smell of sharpies", "Eat paper", "Sleep with the TV on", "Hate sand"], correct: 0 },
  { q: "Why do snakes...", answers: ["Follow you", "Hide in toilets", "Have heat vision", "Climb trees"], correct: 0 },
  { q: "Can you grow...", answers: ["A beard at 12", "A tree in your yard", "Taller by hanging", "Wings"], correct: 0 },
  { q: "Why is my car...", answers: ["Puffing white smoke", "Making a grinding sound", "Losing power", "So dirty"], correct: 0 },
  { q: "Is it legal to...", answers: ["Own a finger monkey", "Build a rocket", "Marry yourself", "Grow hemp"], correct: 0 },
  { q: "Why do I feel...", answers: ["A presence in the room", "Like I'm floating", "Static electricity", "A vibration"], correct: 0 },
  { q: "Can cats eat...", answers: ["Grass", "Popcorn", "Ice cream", "Strawberries"], correct: 0 },
  { q: "Why is the desert...", answers: ["So dry", "Full of cactus", "Beautiful", "Scary"], correct: 0 },
  { q: "Is it true that...", answers: ["Your heart stops when you sneeze", "Sharks can't get cancer", "Bananas are berries", "Gold is soft"], correct: 0 },
  { q: "Why do I dream...", answers: ["In another language", "About my ex", "About snakes", "About being naked"], correct: 0 },
  { q: "Can you survive...", answers: ["A bear attack", "On the sun", "Without a stomach", "A spider bite"], correct: 0 },
  { q: "Why do we say...", answers: ["Knock on wood", "Under the weather", "Bite the bullet", "Cool as a cucumber"], correct: 0 },
];

// ── Utilities ────────────────────────────────────────────────
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function heartSVG() {
  return `<svg viewBox="0 0 24 24" fill="var(--red)" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
  </svg>`;
}

// ── Save/Load ────────────────────────────────────────────────
const SAVE_KEY = 'searchSentry_save';

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      return {
        coins: data.coins ?? 30,
        hearts: data.hearts ?? 5,
        maxLevelUnlocked: data.maxLevelUnlocked ?? 1,
        highScore: data.highScore ?? 0,
        heartTimers: data.heartTimers ?? [],
        usedCodes: data.usedCodes ?? [],
        playerName: data.playerName ?? '',
      };
    }
  } catch (e) {}
  return { coins: 30, hearts: 5, maxLevelUnlocked: 1, highScore: 0, heartTimers: [], usedCodes: [], playerName: '' };
}

function writeSave(data) {
  localStorage.setItem(SAVE_KEY, JSON.stringify(data));
}

// ── Game State ───────────────────────────────────────────────
let save = loadSave();
let currentLevel = 1; // 1-indexed big level
let questionIndex = 0; // current question within this level
let levelQuestions = []; // the questions for this level run
let score = 0;
let streak = 0;
let locked = false;

const LETTERS = ['A', 'B', 'C', 'D'];
const HEART_RECOVERY_MS = 5 * 60 * 1000; // 5 minutes per heart

// ── Level system helpers ─────────────────────────────────────
// Levels 1-5: 5 questions each, 5 coins
// Levels 6-10: 7 questions each, 10 coins
// Levels 11-15: 8 questions each, 15 coins
// Levels 16-20: 9 questions each, 20 coins  (each new 5-level tier adds +1 question and +5 coins)
function questionsForLevel(lvl) {
  const tier = Math.floor((lvl - 1) / 5); // 0 for 1-5, 1 for 6-10, 2 for 11-15, etc.
  if (tier === 0) return 5;
  if (tier === 1) return 7;
  return 7 + (tier - 1); // tier2=8, tier3=9, tier4=10, ...
}
function coinsForLevel(lvl) {
  const tier = Math.floor((lvl - 1) / 5);
  return (tier + 1) * 5; // tier0=5, tier1=10, tier2=15, ...
}
function isMilestoneLevel(lvl) { return lvl % 5 === 0; } // levels 5, 10, 15, 20...

function buildLevelQuestions(lvl) {
  const needed = questionsForLevel(lvl);
  let pool = shuffle(QUESTIONS);
  // If we need more than the pool, cycle through
  while (pool.length < needed) {
    pool = pool.concat(shuffle(QUESTIONS));
  }
  return pool.slice(0, needed);
}

// ── Heart recovery ───────────────────────────────────────────
function processHeartRecovery() {
  const now = Date.now();
  const recovered = [];
  const remaining = [];

  for (const ts of save.heartTimers) {
    if (now - ts >= HEART_RECOVERY_MS) {
      recovered.push(ts);
    } else {
      remaining.push(ts);
    }
  }

  if (recovered.length > 0) {
    save.hearts = Math.min(5, save.hearts + recovered.length);
    save.heartTimers = remaining;
    writeSave(save);
  }
}

function getNextRecoveryTime() {
  if (save.heartTimers.length === 0) return null;
  const oldest = Math.min(...save.heartTimers);
  const remaining = HEART_RECOVERY_MS - (Date.now() - oldest);
  return Math.max(0, remaining);
}

function loseHeart() {
  save.hearts = Math.max(0, save.hearts - 1);
  save.heartTimers.push(Date.now());
  writeSave(save);
}

// ── DOM refs ─────────────────────────────────────────────────
const heartsContainer = document.getElementById('heartsContainer');
const scoreDisplay = document.getElementById('scoreDisplay');
const levelDisplay = document.getElementById('levelDisplay');
const qCounter = document.getElementById('qCounter');
const progressBar = document.getElementById('progressBar');
const searchText = document.getElementById('searchText');
const optionsGrid = document.getElementById('optionsGrid');
const feedbackText = document.getElementById('feedbackText');
const gameArea = document.getElementById('gameArea');
const hudCoins = document.getElementById('hudCoins');

const startScreen = document.getElementById('startScreen');
const startCoins = document.getElementById('startCoins');

const levelSelectScreen = document.getElementById('levelSelectScreen');
const selectCoins = document.getElementById('selectCoins');
const levelButtons = document.getElementById('levelButtons');
const shopPanel = document.getElementById('shopPanel');
const heartsPreview = document.getElementById('heartsPreview');
const recoveryInfo = document.getElementById('recoveryInfo');
const buyFullBtn = document.getElementById('buyFullBtn');
const buySingleBtn = document.getElementById('buySingleBtn');

const chestScreen = document.getElementById('chestScreen');
const chestGrid = document.getElementById('chestGrid');
const chestContinueBtn = document.getElementById('chestContinueBtn');

const levelCompleteScreen = document.getElementById('levelCompleteScreen');
const lcSubtitle = document.getElementById('lcSubtitle');
const lcScore = document.getElementById('lcScore');
const lcCoins = document.getElementById('lcCoins');
const lcNextBtn = document.getElementById('lcNextBtn');
const lcMenuBtn = document.getElementById('lcMenuBtn');

const gameOverScreen = document.getElementById('gameOverScreen');
const finalScoreEl = document.getElementById('finalScore');

// ── Render hearts ────────────────────────────────────────────
function renderHearts(container, count, max = 5, showTimers = false) {
  container.innerHTML = '';
  for (let i = 0; i < max; i++) {
    const el = document.createElement('div');
    el.className = 'heart';
    el.innerHTML = heartSVG();

    if (i >= count) {
      // Check if this heart is recovering
      const recoveringIndex = i - count;
      if (showTimers && recoveringIndex < save.heartTimers.length) {
        el.classList.add('recovering');
        const timer = document.createElement('div');
        timer.className = 'heart-timer';
        timer.dataset.timerIndex = recoveringIndex;
        el.appendChild(timer);
      } else {
        el.classList.add('lost');
      }
    }
    container.appendChild(el);
  }
}

function updateHeartTimers() {
  const timers = document.querySelectorAll('.heart-timer');
  const now = Date.now();
  timers.forEach(t => {
    const idx = parseInt(t.dataset.timerIndex);
    if (idx < save.heartTimers.length) {
      const elapsed = now - save.heartTimers[idx];
      const remaining = Math.max(0, HEART_RECOVERY_MS - elapsed);
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      t.textContent = `${mins}:${String(secs).padStart(2, '0')}`;
    }
  });

  // Update recovery info text
  if (recoveryInfo) {
    const next = getNextRecoveryTime();
    if (next !== null && save.hearts < 5) {
      const mins = Math.floor(next / 60000);
      const secs = Math.floor((next % 60000) / 1000);
      recoveryInfo.textContent = `Next heart recovers in ${mins}:${String(secs).padStart(2, '0')} · Hearts auto-recover every 5 min`;
    } else {
      recoveryInfo.textContent = save.hearts < 5 ? 'Hearts auto-recover every 5 min' : 'All hearts full';
    }
  }
}

// ── Typewriter effect ────────────────────────────────────────
function typeText(text, el, speed = 30) {
  return new Promise(resolve => {
    el.textContent = '';
    let i = 0;
    const interval = setInterval(() => {
      el.textContent += text[i];
      i++;
      if (i >= text.length) { clearInterval(interval); resolve(); }
    }, speed);
  });
}

// ── Feedback ─────────────────────────────────────────────────
function showFeedback(text, type) {
  feedbackText.textContent = text;
  feedbackText.className = 'feedback-text visible ' + type;
  setTimeout(() => { feedbackText.className = 'feedback-text'; }, 1800);
}

// ── Coin splash animation ────────────────────────────────────
function showCoinSplash(amount) {
  const el = document.createElement('div');
  el.className = 'coin-splash';
  el.textContent = `+${amount} 🪙`;
  el.style.left = '50%';
  el.style.top = '40%';
  el.style.transform = 'translateX(-50%)';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1300);
}

// ── Show/hide screens ────────────────────────────────────────
function hideAll() {
  const nameScr = document.getElementById('nameScreen');
  [startScreen, levelSelectScreen, chestScreen, levelCompleteScreen, gameOverScreen].forEach(s => s.classList.remove('active'));
  if (nameScr) nameScr.classList.remove('active');
  // Also hide store screen
  const store = document.getElementById('storeScreen');
  if (store) store.classList.remove('active');
  // Also hide duck vortex overlay
  const vortex = document.getElementById('duckVortexOverlay');
  if (vortex) vortex.style.display = 'none';
  gameArea.style.opacity = '0';
  gameArea.style.pointerEvents = 'none';
}

// ── Start Screen ─────────────────────────────────────────────
function showStartScreen() {
  processHeartRecovery();
  hideAll();
  startCoins.textContent = save.coins;
  startScreen.classList.add('active');
}

// ── Level Select Screen ──────────────────────────────────────
function showLevelSelect() {
  processHeartRecovery();
  hideAll();
  selectCoins.textContent = save.coins;
  renderHearts(heartsPreview, save.hearts, 5, true);

  // Build level buttons
  levelButtons.innerHTML = '';
  const maxLevel = Math.min(save.maxLevelUnlocked + 1, 30); // show up to one beyond unlocked, cap at 30
  const milestoneColors = ['milestone-red', 'milestone-purple', 'milestone-orange']; // cycles every 3 milestones

  for (let i = 1; i <= maxLevel; i++) {
    const unlocked = i <= save.maxLevelUnlocked;
    const isMilestone = isMilestoneLevel(i);
    const btn = document.createElement('button');

    // Determine base class
    let btnClass = 'screen-btn';
    if (!unlocked) {
      btnClass += ' secondary';
    } else if (isMilestone) {
      // Cycle: 5→red, 10→purple, 15→orange, 20→red, 25→purple, 30→orange...
      const msIndex = (i / 5 - 1) % 3;
      btnClass += ' ' + milestoneColors[msIndex];
    }
    btn.className = btnClass;
    btn.style.padding = '10px 16px';
    btn.style.fontSize = '11px';
    btn.style.minWidth = '80px';

    const qCount = questionsForLevel(i);
    const cReward = coinsForLevel(i);
    const milestone = isMilestone ? ' 🎁' : '';
    btn.innerHTML = `LVL ${i}<br><span style="font-size:9px;opacity:0.6">${qCount}Q · ${cReward}🪙${milestone}</span>`;

    if (!unlocked) {
      btn.disabled = true;
      btn.innerHTML = `LVL ${i}<br><span style="font-size:9px;opacity:0.6">🔒 Locked</span>`;
    } else {
      btn.addEventListener('click', () => startLevel(i));
    }

    // Wrap milestone buttons with glowing stars
    if (isMilestone) {
      const wrap = document.createElement('div');
      wrap.className = 'milestone-btn-wrap';
      wrap.appendChild(btn);
      // Add 3 tiny animated stars in upper-right corner
      const starsDiv = document.createElement('div');
      starsDiv.className = 'milestone-stars';
      starsDiv.innerHTML = '<span class="ms-star">✦</span><span class="ms-star">✦</span><span class="ms-star">✦</span>';
      wrap.appendChild(starsDiv);
      levelButtons.appendChild(wrap);
    } else {
      levelButtons.appendChild(btn);
    }
  }

  // Shop buttons
  buyFullBtn.disabled = save.coins < 10 || save.hearts >= 5;
  buySingleBtn.disabled = save.coins < 2 || save.hearts >= 5;

  levelSelectScreen.classList.add('active');
}

// ── Shop ─────────────────────────────────────────────────────
buyFullBtn.addEventListener('click', () => {
  if (save.coins >= 10 && save.hearts < 5) {
    save.coins -= 10;
    save.hearts = 5;
    save.heartTimers = [];
    writeSave(save);
    showCoinSplash(-10);
    showLevelSelect();
  }
});

buySingleBtn.addEventListener('click', () => {
  if (save.coins >= 2 && save.hearts < 5) {
    save.coins -= 2;
    save.hearts = Math.min(5, save.hearts + 1);
    // Remove oldest timer if any
    if (save.heartTimers.length > 0) save.heartTimers.shift();
    writeSave(save);
    showCoinSplash(-2);
    showLevelSelect();
  }
});

// ── Start a level ────────────────────────────────────────────
function startLevel(lvl) {
  if (save.hearts <= 0) {
    // Show a styled "no hearts" toast instead of alert
    const toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;background:rgba(10,14,26,0.95);border:1px solid rgba(255,61,90,0.4);border-radius:16px;padding:28px 32px;text-align:center;font-family:Rajdhani,sans-serif;animation:fadeIn 0.3s ease;max-width:320px;width:90%';
    toast.innerHTML = `
      <img src="assets/pasted-image-2026-03-28T07-18-06.png" style="width:80px;height:50px;object-fit:cover;margin-bottom:10px;filter:drop-shadow(0 0 12px rgba(255,61,90,0.5));border-radius:8px" onerror="this.style.display='none'" />
      <div style="font-size:20px;font-weight:700;color:#ff3d5a;margin-bottom:6px">No Hearts Left!</div>
      <div style="font-size:14px;color:rgba(255,255,255,0.6);margin-bottom:14px">Buy hearts in the Vault or wait for recovery</div>
      <div style="display:flex;gap:8px;justify-content:center">
        <button id="noHeartBuyBtn" style="background:rgba(255,215,0,0.15);border:1px solid rgba(255,215,0,0.3);color:#ffd700;padding:10px 18px;border-radius:8px;font-family:Orbitron,sans-serif;font-size:11px;cursor:pointer">🏪 Buy Hearts (15🪙)</button>
        <button id="noHeartCloseBtn" style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.15);color:#fff;padding:10px 18px;border-radius:8px;font-family:Orbitron,sans-serif;font-size:11px;cursor:pointer">Close</button>
      </div>
    `;
    document.body.appendChild(toast);
    toast.querySelector('#noHeartCloseBtn').onclick = () => toast.remove();
    toast.querySelector('#noHeartBuyBtn').onclick = () => {
      if (save.coins >= 15) {
        save.coins -= 15;
        save.hearts = Math.min(save.hearts + 1, 5);
        writeSave(save);
        updateAllCoinDisplays();
        renderHearts(heartsPreview, save.hearts, 5, true);
        toast.remove();
      } else {
        const buyBtn = toast.querySelector('#noHeartBuyBtn');
        buyBtn.textContent = '❌ Not enough coins';
        buyBtn.style.color = '#ff3d5a';
        setTimeout(() => { buyBtn.textContent = '🏪 Buy Hearts (15🪙)'; buyBtn.style.color = '#ffd700'; }, 1500);
      }
    };
    return;
  }

  currentLevel = lvl;
  questionIndex = 0;
  score = 0;
  streak = 0;
  locked = false;
  levelQuestions = buildLevelQuestions(lvl);

  hideAll();
  scoreDisplay.textContent = '0';
  hudCoins.textContent = save.coins;
  renderHearts(heartsContainer, save.hearts);
  progressBar.style.width = '0%';
  gameArea.style.opacity = '1';
  gameArea.style.pointerEvents = 'auto';

  loadQuestion();
}

// ── Load a question ──────────────────────────────────────────
let currentShuffledCorrect = 0; // track where the correct answer ended up after shuffle

async function loadQuestion() {
  locked = true;
  const q = levelQuestions[questionIndex];
  const total = levelQuestions.length;

  levelDisplay.textContent = `LVL ${String(currentLevel).padStart(2, '0')}`;
  qCounter.textContent = `Q ${questionIndex + 1} / ${total}`;
  progressBar.style.width = ((questionIndex / total) * 100) + '%';
  hudCoins.textContent = save.coins;

  optionsGrid.innerHTML = '';
  await typeText(q.q, searchText, 30);

  // Shuffle answers so correct isn't always at index 0
  const correctAnswer = q.answers[q.correct];
  const shuffledAnswers = shuffle([...q.answers]);
  currentShuffledCorrect = shuffledAnswers.indexOf(correctAnswer);

  shuffledAnswers.forEach((answer, idx) => {
    const btn = document.createElement('button');
    btn.className = 'option-btn';
    btn.innerHTML = `
      <span class="option-letter">${LETTERS[idx]}</span>
      <span class="option-text">${answer}</span>
    `;
    btn.addEventListener('click', () => handleAnswer(idx, btn));
    optionsGrid.appendChild(btn);
  });

  locked = false;
}

// ── Handle answer ────────────────────────────────────────────
function handleAnswer(idx, btn) {
  if (locked) return;
  locked = true;

  const allBtns = optionsGrid.querySelectorAll('.option-btn');
  allBtns.forEach(b => b.classList.add('disabled'));
  allBtns[currentShuffledCorrect].classList.add('correct');

  if (idx === currentShuffledCorrect) {
    streak++;
    const bonus = streak >= 3 ? 50 : 0;
    score += 100 + bonus;
    scoreDisplay.textContent = score;
    triggerGlowPulse('gold');
    if (bonus > 0) {
      showFeedback(`Correct! +${100 + bonus} Streak x${streak}`, 'correct-fb');
    } else {
      showFeedback('Correct! +100', 'correct-fb');
    }
  } else {
    streak = 0;
    btn.classList.add('wrong');
    loseHeart();

    const heartEls = heartsContainer.querySelectorAll('.heart');
    if (heartEls[save.hearts]) {
      heartEls[save.hearts].classList.add('breaking');
      setTimeout(() => heartEls[save.hearts].classList.add('lost'), 500);
    }

    triggerGlowPulse('red');
    showFeedback('Wrong! -1 Heart', 'wrong-fb');

    if (save.hearts <= 0) {
      setTimeout(() => showGameOver(), 1200);
      return;
    }
  }

  questionIndex++;
  if (questionIndex >= levelQuestions.length) {
    setTimeout(() => showLevelComplete(), 1200);
    return;
  }

  setTimeout(() => loadQuestion(), 1400);
}

// ── Level Complete ───────────────────────────────────────────
function showLevelComplete() {
  const reward = coinsForLevel(currentLevel);
  save.coins += reward;
  if (currentLevel >= save.maxLevelUnlocked) {
    save.maxLevelUnlocked = currentLevel + 1;
  }
  if (score > save.highScore) save.highScore = score;
  writeSave(save);

  hideAll();

  // If milestone level, show chest screen first
  if (isMilestoneLevel(currentLevel)) {
    showChestScreen(reward);
    return;
  }

  lcSubtitle.textContent = `Level ${currentLevel} cleared`;
  lcScore.textContent = score;
  lcCoins.textContent = reward;
  progressBar.style.width = '100%';
  levelCompleteScreen.classList.add('active');
}

// ── Chest Screen (milestone levels) ──────────────────────────
function showChestScreen(baseReward) {
  hideAll();
  chestGrid.innerHTML = '';
  chestContinueBtn.style.display = 'none';

  // Generate 3 chests with random rewards: one random from [5,10,15,20,25,30,35,40,45,50]
  const possibleRewards = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
  const chestRewards = [];
  for (let i = 0; i < 3; i++) {
    chestRewards.push(possibleRewards[Math.floor(Math.random() * possibleRewards.length)]);
  }

  let chestPicked = false;

  for (let i = 0; i < 3; i++) {
    const box = document.createElement('div');
    box.className = 'chest-box';
    box.innerHTML = `
      <div class="chest-icon">🎁</div>
      <div class="chest-label">Chest ${i + 1}</div>
      <div class="chest-reward" id="chestReward${i}">+${chestRewards[i]} 🪙</div>
    `;

    box.addEventListener('click', () => {
      if (chestPicked) return;
      chestPicked = true;

      // Reveal all chests
      const allBoxes = chestGrid.querySelectorAll('.chest-box');
      allBoxes.forEach((b, idx) => {
        b.classList.add('opened');
        if (idx === i) b.classList.add('selected');
        const rewardEl = document.getElementById(`chestReward${idx}`);
        rewardEl.classList.add('show');
      });

      // Award the chosen chest
      save.coins += chestRewards[i];
      writeSave(save);
      showCoinSplash(chestRewards[i]);

      chestContinueBtn.style.display = 'inline-block';
    });

    chestGrid.appendChild(box);
  }

  chestScreen.classList.add('active');

  // When continue is clicked, go to level complete
  chestContinueBtn.onclick = () => {
    hideAll();
    lcSubtitle.textContent = `Level ${currentLevel} cleared · Milestone bonus!`;
    lcScore.textContent = score;
    lcCoins.textContent = baseReward + ' + Chest bonus';
    levelCompleteScreen.classList.add('active');
  };
}

// ── Game Over — Duck Vortex Animation ────────────────────────
// Meme images for game over screen — randomly picked each time
const GAME_OVER_MEMES = [
  'assets/1d52901a055ee7268bb3a9f769336cb3_1774685440265.jpg',
  'assets/1f6a4d85c78217280cb37f1124e11187_1774685440266.jpg',
  'assets/3dd42712a778255906ff45634bf6e92e_1774685440270.jpg',
  'assets/3f13f2af7338fff33302e806be4f9853_1774685440272.jpg',
  'assets/4fd1d202700b5d844c9e612d535db508_1774685440273.jpg',
  'assets/7cac3de94147e0cc5219413dd40948a0_1774685453322.jpg',
  'assets/7cadd8c14d814778ad6bea5d4cb1637d_1774685453325.jpg',
  'assets/7d3a472bd89f86da4f9621275702ba40_1774685453326.jpg',
  'assets/7dbb7ddd0cca2e940bc68dc8088ac025_1774685453327.jpg',
  'assets/12efd6637144d2826ae128853062a62b_1774685453328.jpg',
  'assets/036aaef03f5687aa7f338c9ab455031a_1774685453328.jpg',
  'assets/45aa7f75691da56ee92ce2e99e9bd499_1774685453329.jpg',
  'assets/56ae84205e558a44655d40f5d3fd5f5f_1774685453330.jpg',
];

function showGameOver() {
  // Save score
  if (score > save.highScore) {
    save.highScore = score;
    writeSave(save);
  }

  // Start the duck vortex sucking animation
  playDuckVortex(() => {
    hideAll();
    finalScoreEl.textContent = score;

    // Pick a random meme image
    const memeImg = document.getElementById('gameOverMemeImg');
    const memeContainer = document.getElementById('gameOverMemeContainer');
    if (memeImg) {
      // Shuffle and pick from pool, preload each until one works
      const shuffled = [...GAME_OVER_MEMES].sort(() => Math.random() - 0.5);
      let tryIdx = 0;
      const tryNext = () => {
        if (tryIdx >= shuffled.length) return;
        const src = shuffled[tryIdx++];
        const probe = new Image();
        probe.onload = () => { memeImg.src = src; };
        probe.onerror = tryNext;
        probe.src = src;
      };
      tryNext();
    }
    // Re-trigger the slam animation
    if (memeContainer) {
      memeContainer.style.animation = 'none';
      memeContainer.offsetHeight; // force reflow
      memeContainer.style.animation = '';
    }

    gameOverScreen.classList.add('active');
  });
}

function playDuckVortex(onComplete) {
  const overlay = document.getElementById('duckVortexOverlay');
  const canvas = document.getElementById('vortexCanvas');
  const duckImg = document.getElementById('duckVortexImg');
  const ctx = canvas.getContext('2d');

  // Pick a random duck hero frame for the vortex
  const heroFrames = [];
  for(let i=0;i<31;i++){
    heroFrames.push('assets/2.mp4-frame-'+String(i).padStart(2,'0')+'.png');
  }
  const randomFrame = heroFrames[Math.floor(Math.random()*heroFrames.length)];
  duckImg.src = randomFrame;

  overlay.style.display = 'block';

  const W = window.innerWidth;
  const H = window.innerHeight;
  canvas.width = W;
  canvas.height = H;

  // Position duck at center — start small then grow (wider for landscape duck image)
  const duckSize = Math.min(W, H) * 0.35;
  const duckX = W / 2;
  const duckY = H / 2;
  duckImg.style.width = '0px';
  duckImg.style.height = '0px';
  duckImg.style.left = duckX + 'px';
  duckImg.style.top = duckY + 'px';
  duckImg.style.transform = 'translate(-50%,-50%)';
  duckImg.style.opacity = '0';
  duckImg.style.borderRadius = '16px';

  // Particle system — page elements get sucked into the palm
  const particles = [];
  const numParticles = 120;
  for (let i = 0; i < numParticles; i++) {
    // Spawn from edges of screen
    const edge = Math.random();
    let px, py;
    if (edge < 0.25) { px = Math.random() * W; py = -20; }
    else if (edge < 0.5) { px = Math.random() * W; py = H + 20; }
    else if (edge < 0.75) { px = -20; py = Math.random() * H; }
    else { px = W + 20; py = Math.random() * H; }

    particles.push({
      x: px, y: py,
      size: 3 + Math.random() * 8,
      speed: 0.5 + Math.random() * 2,
      angle: Math.atan2(duckY - py, duckX - px),
      dist: Math.hypot(duckX - px, duckY - py),
      progress: 0,
      color: ['#ff3d5a','#ffd700','#00e5ff','#ff6b3d','#ffffff','#ff3d5a'][Math.floor(Math.random()*6)],
      delay: Math.random() * 800,
      startX: px, startY: py
    });
  }

  let startTime = null;
  const DURATION = 3200; // total vortex duration in ms

  function animateVortex(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;
    const t = Math.min(elapsed / DURATION, 1);

    ctx.clearRect(0, 0, W, H);

    // Darken background progressively
    ctx.fillStyle = `rgba(6,8,15,${t * 0.92})`;
    ctx.fillRect(0, 0, W, H);

    // Phase 1 (0-0.3): Duck appears and grows with glow
    if (t < 0.35) {
      const duckT = t / 0.35;
      const eased = 1 - Math.pow(1 - duckT, 3);
      const curW = duckSize * 1.6 * eased; // wider for landscape image
      const curH = duckSize * eased;
      duckImg.style.width = curW + 'px';
      duckImg.style.height = curH + 'px';
      duckImg.style.opacity = String(eased);
      // Red glow behind duck
      const glowR = curH * 0.8;
      const grad = ctx.createRadialGradient(duckX, duckY, 0, duckX, duckY, glowR);
      grad.addColorStop(0, `rgba(255,61,90,${0.4*eased})`);
      grad.addColorStop(0.5, `rgba(255,61,90,${0.15*eased})`);
      grad.addColorStop(1, 'rgba(255,61,90,0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(duckX, duckY, glowR, 0, Math.PI * 2);
      ctx.fill();
    }

    // Phase 2 (0.2-0.85): Vortex spiral — particles swirl toward palm
    if (t > 0.15) {
      const vortexT = Math.min((t - 0.15) / 0.7, 1);

      // Draw spiral lines
      ctx.strokeStyle = `rgba(255,61,90,${0.15 * (1 - vortexT * 0.5)})`;
      ctx.lineWidth = 1.5;
      for (let s = 0; s < 6; s++) {
        ctx.beginPath();
        const baseAngle = (s / 6) * Math.PI * 2 + elapsed * 0.003;
        for (let r = 10; r < Math.min(W, H) * 0.6 * (1 - vortexT * 0.6); r += 3) {
          const spiralAngle = baseAngle + r * 0.015;
          const sx = duckX + Math.cos(spiralAngle) * r;
          const sy = duckY + Math.sin(spiralAngle) * r;
          if (r === 10) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }
        ctx.stroke();
      }

      // Animate particles spiraling in
      particles.forEach(p => {
        const pElapsed = Math.max(0, elapsed - p.delay);
        if (pElapsed <= 0) return;

        const pT = Math.min(pElapsed / (DURATION * 0.65), 1);
        const eased = pT * pT;
        const spiralAngle = p.angle + pT * Math.PI * 4;
        const curDist = p.dist * (1 - eased);

        p.x = duckX + Math.cos(spiralAngle) * curDist * (1 - eased * 0.3);
        p.y = duckY + Math.sin(spiralAngle) * curDist * (1 - eased * 0.3);

        const alpha = pT < 0.8 ? 1 : 1 - (pT - 0.8) / 0.2;
        const curSize = p.size * (1 - eased * 0.7);

        ctx.beginPath();
        ctx.arc(p.x, p.y, curSize, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(')', `,${alpha})`).replace('rgb', 'rgba').replace('##', '#');
        // Simple fallback for hex colors
        const r2 = parseInt(p.color.slice(1,3),16) || 255;
        const g2 = parseInt(p.color.slice(3,5),16) || 100;
        const b2 = parseInt(p.color.slice(5,7),16) || 100;
        ctx.fillStyle = `rgba(${r2},${g2},${b2},${alpha})`;
        ctx.fill();

        // Particle trail
        if (curSize > 2) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          const trailLen = curDist * 0.08;
          ctx.lineTo(p.x + Math.cos(spiralAngle + Math.PI) * trailLen,
                     p.y + Math.sin(spiralAngle + Math.PI) * trailLen);
          ctx.strokeStyle = `rgba(${r2},${g2},${b2},${alpha * 0.4})`;
          ctx.lineWidth = curSize * 0.5;
          ctx.stroke();
        }
      });
    }

    // Phase 3 (0.7-1.0): Screen distortion — everything shrinks to center
    if (t > 0.7) {
      const shrinkT = (t - 0.7) / 0.3;
      const eased = shrinkT * shrinkT * shrinkT;

      // Radial "sucking" gradient
      const suckGrad = ctx.createRadialGradient(duckX, duckY, 0, duckX, duckY, Math.max(W,H)*0.8);
      suckGrad.addColorStop(0, `rgba(6,8,15,${eased})`);
      suckGrad.addColorStop(0.3, `rgba(6,8,15,${eased * 0.8})`);
      suckGrad.addColorStop(1, `rgba(6,8,15,${eased * 0.4})`);
      ctx.fillStyle = suckGrad;
      ctx.fillRect(0, 0, W, H);

      // Duck pulses at end
      const pulse = 1 + Math.sin(elapsed * 0.02) * 0.05 * (1 - shrinkT);
      duckImg.style.transform = `translate(-50%,-50%) scale(${pulse * (1 + shrinkT * 0.15)})`;
    }

    // Duck subtle float
    if (t > 0.35) {
      const floatY = Math.sin(elapsed * 0.004) * 5;
      duckImg.style.top = (duckY + floatY) + 'px';
    }

    if (t < 1) {
      requestAnimationFrame(animateVortex);
    } else {
      // Final flash
      ctx.fillStyle = 'rgba(255,61,90,0.3)';
      ctx.fillRect(0, 0, W, H);
      setTimeout(() => {
        overlay.style.display = 'none';
        duckImg.style.opacity = '0';
        ctx.clearRect(0, 0, W, H);
        onComplete();
      }, 400);
    }
  }

  requestAnimationFrame(animateVortex);
}

// ── Name Entry Screen ────────────────────────────────────────
function showNameScreen() {
  hideAll();
  const nameScreen = document.getElementById('nameScreen');
  const nameInput = document.getElementById('playerNameInput');
  const confirmBtn = document.getElementById('nameConfirmBtn');
  const charCount = document.getElementById('nameCharCount');
  const nameError = document.getElementById('nameError');

  // Reset state
  nameInput.value = '';
  nameError.textContent = '';
  confirmBtn.style.opacity = '0.4';
  confirmBtn.style.pointerEvents = 'none';
  charCount.textContent = '0 / 30';

  // Remove old listeners by cloning
  const newInput = nameInput.cloneNode(true);
  nameInput.parentNode.replaceChild(newInput, nameInput);
  const newBtn = confirmBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newBtn, confirmBtn);

  // Re-grab refs
  const input = document.getElementById('playerNameInput');
  const btn = document.getElementById('nameConfirmBtn');
  const counter = document.getElementById('nameCharCount');
  const errDiv = document.getElementById('nameError');

  // Input handler — enable button when at least 1 char typed
  input.addEventListener('input', () => {
    const val = input.value;
    counter.textContent = val.length + ' / 30';
    if (val.trim().length > 0) {
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
      errDiv.textContent = '';
    } else {
      btn.style.opacity = '0.4';
      btn.style.pointerEvents = 'none';
    }
  });

  // Enter key to confirm
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && input.value.trim().length > 0) {
      confirmPlayerName(input.value.trim());
    }
  });

  // Button click
  btn.addEventListener('click', () => {
    if (input.value.trim().length > 0) {
      confirmPlayerName(input.value.trim());
    } else {
      errDiv.textContent = 'Please enter a name, agent!';
    }
  });

  nameScreen.classList.add('active');

  // Auto-focus with small delay for mobile keyboards
  setTimeout(() => input.focus(), 300);
}

function confirmPlayerName(name) {
  save.playerName = name;
  writeSave(save);

  const nameScreen = document.getElementById('nameScreen');
  const btn = document.getElementById('nameConfirmBtn');

  // Cool confirmation animation
  btn.textContent = '✓ LOCKED IN';
  btn.style.background = 'linear-gradient(135deg, rgba(57,255,20,0.3), rgba(57,255,20,0.1))';
  btn.style.borderColor = 'rgba(57,255,20,0.6)';
  btn.style.color = '#39ff14';
  btn.style.pointerEvents = 'none';

  // Flash the name golden
  const input = document.getElementById('playerNameInput');
  input.style.borderColor = 'rgba(255,215,0,0.8)';
  input.style.boxShadow = '0 0 30px rgba(255,215,0,0.2), inset 0 0 20px rgba(255,215,0,0.05)';
  input.style.color = '#ffd700';
  input.disabled = true;

  // Transition to level select after a beat
  setTimeout(() => {
    showLevelSelect();
  }, 800);
}

// ── Button wiring ────────────────────────────────────────────
document.getElementById('startBtn').addEventListener('click', () => {
  // If player already has a name saved, skip name entry
  if (save.playerName && save.playerName.trim().length > 0) {
    showLevelSelect();
  } else {
    showNameScreen();
  }
});
// ── Game Over: Home Page button → go to start screen ────────
document.getElementById('goMenuBtn').addEventListener('click', () => {
  hideAll();
  startScreen.classList.add('active');
});

// ── Game Over: Buy Hearts button ────────────────────────────
document.getElementById('buyHeartsBtn').addEventListener('click', () => {
  const HEART_COST = 15;
  const btn = document.getElementById('buyHeartsBtn');
  if (save.coins >= HEART_COST) {
    save.coins -= HEART_COST;
    save.hearts = Math.min(save.hearts + 1, 5);
    writeSave(save);
    btn.textContent = '✅ +1 Heart!';
    btn.style.background = 'linear-gradient(135deg,#39ff14,#00cc00)';
    setTimeout(() => {
      btn.textContent = '❤️ Buy Hearts';
      btn.style.background = 'linear-gradient(135deg,#ffd700,#ffaa00)';
    }, 1200);
    updateAllCoinDisplays();
  } else {
    btn.textContent = '❌ Not enough coins';
    btn.style.background = 'linear-gradient(135deg,#ff3d5a,#cc0022)';
    setTimeout(() => {
      btn.textContent = '❤️ Buy Hearts';
      btn.style.background = 'linear-gradient(135deg,#ffd700,#ffaa00)';
    }, 1500);
  }
});

// ── Game Over: Complain button → open Instagram ─────────────
document.getElementById('complainBtn').addEventListener('click', () => {
  window.open('https://www.instagram.com/toniez.ng', '_blank');
});

lcNextBtn.addEventListener('click', () => {
  processHeartRecovery();
  if (save.hearts > 0) {
    startLevel(currentLevel + 1);
  } else {
    showLevelSelect();
  }
});
lcMenuBtn.addEventListener('click', () => showLevelSelect());

// ── Exit button (save & quit mid-game) ──────────────────────
document.getElementById('exitBtn').addEventListener('click', () => {
  if (locked && questionIndex < levelQuestions.length) {
    // If in the middle of answer animation, ignore
  }
  // Show a confirmation modal
  const modal = document.createElement('div');
  modal.className = 'exit-modal';
  modal.innerHTML = `
    <div class="exit-modal-box">
      <div class="exit-modal-title">Exit Mission?</div>
      <div class="exit-modal-text">
        Your progress on this level will be lost, but your coins and hearts are saved.
      </div>
      <div class="btn-row">
        <button class="screen-btn" id="exitConfirmBtn">Save & Exit</button>
        <button class="screen-btn secondary" id="exitCancelBtn">Continue</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  document.getElementById('exitConfirmBtn').addEventListener('click', () => {
    modal.remove();
    writeSave(save);
    showLevelSelect();
  });
  document.getElementById('exitCancelBtn').addEventListener('click', () => {
    modal.remove();
  });
});

// ── Recovery tick (update timers every second) ───────────────
setInterval(() => {
  const prevHearts = save.hearts;
  processHeartRecovery();
  updateHeartTimers();

  // Refresh shop buttons if on level select
  if (levelSelectScreen.classList.contains('active')) {
    buyFullBtn.disabled = save.coins < 10 || save.hearts >= 5;
    buySingleBtn.disabled = save.coins < 2 || save.hearts >= 5;
    selectCoins.textContent = save.coins;
    if (save.hearts !== prevHearts) {
      renderHearts(heartsPreview, save.hearts, 5, true);
    }
  }
}, 1000);

// ═══════════════════════════════════════════════════════════════
// Duckiez Vault Store System
// ═══════════════════════════════════════════════════════════════

const STORE_SAVE_KEY = 'searchSentry_store';

function loadStoreSave() {
  try {
    const raw = localStorage.getItem(STORE_SAVE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      return {
        purchased: data.purchased ?? [],
        equipped: data.equipped ?? null,
        equippedPattern: data.equippedPattern ?? null,
      };
    }
  } catch (e) {}
  return { purchased: [], equipped: null, equippedPattern: null };
}

function writeStoreSave(data) {
  localStorage.setItem(STORE_SAVE_KEY, JSON.stringify(data));
}

let storeSave = loadStoreSave();
let currentStoreTab = 'common';
let previewTimer = null;
let previewCountdown = 0;
let previewOverlay = null;
let activeBackground = null; // tracks currently applied bg

// ── Store Item Definitions ───────────────────────────────────

const STORE_ITEMS = {
  common: [
    { id: 'c_neon_gold', name: 'Neon Gold', price: 10, color: '#FFD700' },
    { id: 'c_deep_navy', name: 'Deep Navy', price: 10, color: '#0B0E14' },
    { id: 'c_arctic_white', name: 'Arctic White', price: 10, color: '#E0E0E0' },
    { id: 'c_electric_blue', name: 'Electric Blue', price: 10, color: '#007BFF' },
    { id: 'c_emerald', name: 'Emerald', price: 10, color: '#2ECC71' },
    { id: 'c_crimson', name: 'Crimson', price: 10, color: '#E74C3C' },
    { id: 'c_void_black', name: 'Void Black', price: 10, color: '#050505' },
    { id: 'c_royal_purple', name: 'Royal Purple', price: 10, color: '#6C3483' },
    { id: 'c_burnt_orange', name: 'Burnt Orange', price: 10, color: '#E67E22' },
    { id: 'c_steel_gray', name: 'Steel Gray', price: 10, color: '#2C3E50' },
  ],
  basic: [
    { id: 'b_hex_grid', name: 'Hexagons', price: 20, pattern: 'hexagons' },
    { id: 'b_circuit', name: 'Circuit Board', price: 20, pattern: 'circuit' },
    { id: 'b_dots', name: 'Dot Matrix', price: 20, pattern: 'dots' },
    { id: 'b_lines', name: 'Simple Lines', price: 20, pattern: 'lines' },
    { id: 'b_radar', name: 'Radar Sweep', price: 20, pattern: 'radar' },
    { id: 'b_binary', name: 'Binary Rain', price: 20, pattern: 'binary' },
    { id: 'b_triangles', name: 'Triangles', price: 20, pattern: 'triangles' },
    { id: 'b_crosshatch', name: 'Crosshatch', price: 20, pattern: 'crosshatch' },
    { id: 'b_waves', name: 'Sine Waves', price: 20, pattern: 'waves' },
    { id: 'b_diamonds', name: 'Diamonds', price: 20, pattern: 'diamonds' },
    { id: 'b_scanlines', name: 'Scanlines', price: 20, pattern: 'scanlines' },
    { id: 'b_spiral', name: 'Spiral', price: 20, pattern: 'spiral' },
    { id: 'b_noise', name: 'Static Noise', price: 20, pattern: 'noise' },
    { id: 'b_concentric', name: 'Concentric', price: 20, pattern: 'concentric' },
    { id: 'b_grid_pulse', name: 'Grid Pulse', price: 20, pattern: 'gridpulse' },
  ],
  epic: [
    { id: 'e_nebula', name: 'Nebula', price: 100, gradient: ['#1a0533', '#2d1b69', '#0d1b2a', '#1b0a3c'] },
    { id: 'e_aurora', name: 'Aurora', price: 100, gradient: ['#0a1628', '#0d3b2e', '#1a4a3a', '#0a2a1a'] },
    { id: 'e_inferno', name: 'Inferno', price: 100, gradient: ['#1a0000', '#4a0000', '#2a0500', '#0a0000'] },
    { id: 'e_ocean_deep', name: 'Ocean Deep', price: 100, gradient: ['#000a1a', '#001a3a', '#00203a', '#000510'] },
    { id: 'e_twilight', name: 'Twilight', price: 100, gradient: ['#1a0a2e', '#2a1040', '#0a0a28', '#1a0020'] },
    { id: 'e_ember', name: 'Ember Glow', price: 100, gradient: ['#1a0800', '#2a1000', '#3a1500', '#0a0400'] },
    { id: 'e_frost', name: 'Frostbite', price: 100, gradient: ['#0a1520', '#0d2030', '#081828', '#0a0f18'] },
    { id: 'e_solar', name: 'Solar Flare', price: 100, gradient: ['#1a1000', '#2a1800', '#1a0800', '#0a0500'] },
    { id: 'e_void', name: 'The Void', price: 100, gradient: ['#020204', '#050510', '#020208', '#010102'] },
    { id: 'e_plasma', name: 'Plasma Storm', price: 100, gradient: ['#0a0020', '#1a0040', '#200050', '#050010'] },
  ],
  elite: [
    { id: 'x_golden_grid', name: 'The Golden Grid', price: 500, bg3d: 'goldenGrid' },
    { id: 'x_stark_terminal', name: 'Stark Terminal', price: 500, bg3d: 'starkTerminal' },
    { id: 'x_duckiez_matrix', name: 'Duckiez Matrix', price: 500, bg3d: 'duckiezMatrix' },
    { id: 'x_warp_core', name: 'The Warp Core', price: 500, bg3d: 'warpCore' },
    { id: 'x_liquid_gold', name: 'Liquid Gold', price: 500, bg3d: 'liquidGold' },
  ],
};

const TIER_META = {
  common: { label: 'Common', badge: 'tier-common', priceLabel: '10🪙' },
  basic: { label: 'Basic', badge: 'tier-basic', priceLabel: '20🪙' },
  epic: { label: 'Epic', badge: 'tier-epic', priceLabel: '100🪙' },
  elite: { label: 'Elite', badge: 'tier-elite', priceLabel: '500🪙' },
};

// ── Pattern drawing for Basic tier previews ──────────────────

function drawPattern(ctx, w, h, type, t) {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = 'rgba(6,8,15,0.95)';
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = 'rgba(245,197,24,0.25)';
  ctx.fillStyle = 'rgba(245,197,24,0.15)';
  ctx.lineWidth = 1;

  switch (type) {
    case 'hexagons': {
      const s = 14;
      for (let y = -s; y < h + s * 2; y += s * 1.5) {
        for (let x = -s; x < w + s * 2; x += s * 1.73) {
          const ox = (Math.floor(y / (s * 1.5)) % 2) * s * 0.865;
          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const a = Math.PI / 3 * i + t * 0.5;
            const px = x + ox + Math.cos(a) * s * 0.5;
            const py = y + Math.sin(a) * s * 0.5;
            i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
          }
          ctx.closePath(); ctx.stroke();
        }
      }
      break;
    }
    case 'circuit': {
      const step = 16;
      for (let y = 0; y < h; y += step) {
        for (let x = 0; x < w; x += step) {
          if (Math.random() > 0.6) {
            ctx.beginPath(); ctx.arc(x, y, 2, 0, Math.PI * 2); ctx.fill();
          }
          if (Math.random() > 0.5) {
            ctx.beginPath(); ctx.moveTo(x, y);
            ctx.lineTo(x + step * (Math.random() > 0.5 ? 1 : 0), y + step * (Math.random() > 0.5 ? 1 : 0));
            ctx.stroke();
          }
        }
      }
      break;
    }
    case 'dots': {
      const sp = 10;
      for (let y = 0; y < h; y += sp) {
        for (let x = 0; x < w; x += sp) {
          const pulse = Math.sin(t * 2 + x * 0.1 + y * 0.1) * 0.5 + 0.5;
          ctx.globalAlpha = 0.1 + pulse * 0.3;
          ctx.beginPath(); ctx.arc(x, y, 1.5, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      break;
    }
    case 'lines': {
      const sp = 12;
      const off = (t * 8) % sp;
      for (let y = -sp + off; y < h + sp; y += sp) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }
      break;
    }
    case 'radar': {
      const cx = w / 2, cy = h / 2;
      for (let r = 8; r < Math.max(w, h); r += 12) {
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(245,197,24,0.5)';
      ctx.beginPath(); ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(t * 1.5) * w, cy + Math.sin(t * 1.5) * h); ctx.stroke();
      break;
    }
    case 'binary': {
      ctx.font = '8px monospace'; ctx.fillStyle = 'rgba(245,197,24,0.2)';
      for (let x = 0; x < w; x += 10) {
        const yOff = (t * 20 + x * 7) % h;
        for (let y = 0; y < h; y += 10) {
          ctx.fillText(Math.random() > 0.5 ? '1' : '0', x, (y + yOff) % h);
        }
      }
      break;
    }
    case 'triangles': {
      const s = 20;
      for (let y = 0; y < h + s; y += s) {
        for (let x = 0; x < w + s; x += s) {
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + s / 2, y + s);
          ctx.lineTo(x - s / 2, y + s); ctx.closePath(); ctx.stroke();
        }
      }
      break;
    }
    case 'crosshatch': {
      const sp = 10;
      for (let i = -h; i < w + h; i += sp) {
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i + h, h); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(i + h, 0); ctx.lineTo(i, h); ctx.stroke();
      }
      break;
    }
    case 'waves': {
      for (let y = 10; y < h; y += 12) {
        ctx.beginPath();
        for (let x = 0; x <= w; x += 2) {
          ctx.lineTo(x, y + Math.sin(x * 0.08 + t * 2 + y * 0.1) * 5);
        }
        ctx.stroke();
      }
      break;
    }
    case 'diamonds': {
      const s = 16;
      for (let y = 0; y < h + s; y += s) {
        for (let x = 0; x < w + s; x += s) {
          ctx.beginPath(); ctx.moveTo(x, y - s / 2); ctx.lineTo(x + s / 2, y);
          ctx.lineTo(x, y + s / 2); ctx.lineTo(x - s / 2, y); ctx.closePath(); ctx.stroke();
        }
      }
      break;
    }
    case 'scanlines': {
      for (let y = 0; y < h; y += 3) {
        ctx.globalAlpha = 0.05 + Math.sin(y * 0.5 + t) * 0.03;
        ctx.fillRect(0, y, w, 1);
      }
      ctx.globalAlpha = 1;
      break;
    }
    case 'spiral': {
      const cx = w / 2, cy = h / 2;
      ctx.beginPath();
      for (let a = 0; a < Math.PI * 12; a += 0.05) {
        const r = a * 2 + t * 5;
        ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      }
      ctx.stroke();
      break;
    }
    case 'noise': {
      for (let i = 0; i < 300; i++) {
        ctx.globalAlpha = Math.random() * 0.3;
        ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
      }
      ctx.globalAlpha = 1;
      break;
    }
    case 'concentric': {
      const cx = w / 2, cy = h / 2;
      for (let r = 4 + (t * 3 % 12); r < Math.max(w, h); r += 12) {
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      }
      break;
    }
    case 'gridpulse': {
      const sp = 16;
      for (let y = 0; y < h; y += sp) {
        for (let x = 0; x < w; x += sp) {
          const pulse = Math.sin(t * 3 + x * 0.05 + y * 0.05) * 0.5 + 0.5;
          ctx.globalAlpha = 0.05 + pulse * 0.25;
          ctx.strokeRect(x, y, sp, sp);
        }
      }
      ctx.globalAlpha = 1;
      break;
    }
  }
}

// ── Store rendering ──────────────────────────────────────────

const storeTabs = document.getElementById('storeTabs');
const storeGrid = document.getElementById('storeGrid');
const storeCoins = document.getElementById('storeCoins');
const storeScreen = document.getElementById('storeScreen');
const storeBackBtn = document.getElementById('storeBackBtn');
const openStoreBtn = document.getElementById('openStoreBtn');

let patternCanvases = []; // track animated canvases for cleanup
let selectedStoreItem = null; // tracks which item is currently "selected" (yellow glow)

function buildStoreTabs() {
  storeTabs.innerHTML = '';
  for (const [key, meta] of Object.entries(TIER_META)) {
    const tab = document.createElement('button');
    tab.className = 'store-tab' + (key === currentStoreTab ? ' active' : '');
    tab.textContent = meta.label;
    tab.addEventListener('click', () => {
      currentStoreTab = key;
      selectedStoreItem = null;
      renderStore();
    });
    storeTabs.appendChild(tab);
  }
}

// Build the preview swatch/canvas for an item (reusable for store grid + confirm dialog)
function buildItemPreview(item, size) {
  const container = document.createElement('div');
  if (item.color) {
    const swatch = document.createElement('div');
    swatch.className = 'store-swatch';
    swatch.style.background = item.color;
    container.appendChild(swatch);
  } else if (item.pattern) {
    const c = document.createElement('canvas');
    c.width = size === 'large' ? 300 : 160;
    c.height = size === 'large' ? 188 : 100;
    c.style.width = '100%'; c.style.height = '100%';
    container.appendChild(c);
    patternCanvases.push({ canvas: c, pattern: item.pattern });
  } else if (item.gradient) {
    const swatch = document.createElement('div');
    swatch.className = 'store-swatch';
    swatch.style.background = `linear-gradient(135deg, ${item.gradient.join(', ')})`;
    container.appendChild(swatch);
  } else if (item.bg3d) {
    const label = document.createElement('div');
    label.className = 'store-swatch';
    label.style.background = 'linear-gradient(135deg, #0a0a1a, #1a1000, #0a0a1a)';
    label.style.display = 'flex'; label.style.alignItems = 'center'; label.style.justifyContent = 'center';
    label.innerHTML = `<span style="font-size:${size === 'large' ? '36' : '24'}px">✦</span>`;
    container.appendChild(label);
  }
  return container;
}

// Show the confirm-purchase overlay
function showConfirmPurchase(item) {
  // Remove any existing confirm overlay
  const existing = document.querySelector('.store-confirm-overlay');
  if (existing) existing.remove();

  const canAfford = save.coins >= item.price;
  const overlay = document.createElement('div');
  overlay.className = 'store-confirm-overlay';

  const box = document.createElement('div');
  box.className = 'store-confirm-box';

  // Preview
  const preview = document.createElement('div');
  preview.className = 'confirm-preview';
  const previewContent = buildItemPreview(item, 'large');
  preview.appendChild(previewContent);
  box.appendChild(preview);

  // Title
  const title = document.createElement('div');
  title.className = 'confirm-title';
  title.textContent = item.name;
  box.appendChild(title);

  // Price
  const price = document.createElement('div');
  price.className = 'confirm-price';
  price.textContent = `🪙 ${item.price}`;
  box.appendChild(price);

  // Balance info
  const balance = document.createElement('div');
  balance.className = 'confirm-balance' + (canAfford ? '' : ' insufficient');
  balance.textContent = canAfford
    ? `Your balance: 🪙 ${save.coins}  →  🪙 ${save.coins - item.price}`
    : `Not enough coins! You have 🪙 ${save.coins}`;
  box.appendChild(balance);

  // Buttons
  const btns = document.createElement('div');
  btns.className = 'confirm-buttons';

  const noBtn = document.createElement('button');
  noBtn.className = 'confirm-btn no';
  noBtn.textContent = 'Cancel';
  noBtn.addEventListener('click', () => {
    overlay.remove();
  });
  btns.appendChild(noBtn);

  const yesBtn = document.createElement('button');
  yesBtn.className = 'confirm-btn yes';
  yesBtn.textContent = canAfford ? 'Confirm Purchase' : 'Not Enough';
  yesBtn.disabled = !canAfford;
  yesBtn.addEventListener('click', () => {
    overlay.remove();
    buyItem(item);
  });
  btns.appendChild(yesBtn);

  box.appendChild(btns);
  overlay.appendChild(box);

  // Click outside box to close
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.remove();
  });

  document.body.appendChild(overlay);

  // Animate pattern canvases inside confirm dialog
  animatePatternPreviews();
}

function renderStore() {
  buildStoreTabs();
  storeCoins.textContent = save.coins;
  storeGrid.innerHTML = '';
  patternCanvases = [];

  const items = STORE_ITEMS[currentStoreTab] || [];
  const meta = TIER_META[currentStoreTab];

  items.forEach(item => {
    const owned = storeSave.purchased.includes(item.id);
    const isEquipped = storeSave.equipped === item.id || storeSave.equippedPattern === item.id;
    const isSelected = selectedStoreItem === item.id;

    const el = document.createElement('div');
    let cls = 'store-item';
    if (isEquipped) cls += ' equipped';
    if (isSelected && !owned) cls += ' selected';
    el.className = cls;

    // Click on the entire card to select it (yellow glow)
    el.addEventListener('click', () => {
      if (owned) return; // owned items don't need selection
      if (selectedStoreItem === item.id) {
        // Already selected — clicking again opens confirm dialog
        showConfirmPurchase(item);
      } else {
        selectedStoreItem = item.id;
        renderStore();
      }
    });

    // Preview swatch
    const preview = document.createElement('div');
    preview.className = 'store-item-preview';
    const previewContent = buildItemPreview(item, 'small');
    while (previewContent.firstChild) preview.appendChild(previewContent.firstChild);

    // Badge
    const badge = document.createElement('div');
    badge.className = 'tier-badge ' + meta.badge;
    badge.textContent = meta.label;
    preview.appendChild(badge);

    el.appendChild(preview);

    // Name
    const nameEl = document.createElement('div');
    nameEl.className = 'store-item-name';
    nameEl.textContent = item.name;
    el.appendChild(nameEl);

    // Price / Owned label
    if (!owned) {
      const priceEl = document.createElement('div');
      priceEl.className = 'store-item-price';
      priceEl.textContent = `🪙 ${item.price}`;
      el.appendChild(priceEl);
    }

    // Buttons row
    const btnRow = document.createElement('div');
    btnRow.style.display = 'flex'; btnRow.style.gap = '4px'; btnRow.style.alignItems = 'center';
    btnRow.style.flexWrap = 'wrap'; btnRow.style.justifyContent = 'center';

    if (!owned) {
      // Try button (always visible)
      const tryBtn = document.createElement('button');
      tryBtn.className = 'store-buy-btn equip';
      tryBtn.textContent = '👁 Try';
      tryBtn.style.fontSize = '8px'; tryBtn.style.padding = '4px 8px';
      tryBtn.addEventListener('click', (e) => { e.stopPropagation(); startPreview(item); });
      btnRow.appendChild(tryBtn);

      // Buy button only appears when this item is selected (yellow glow active)
      if (isSelected) {
        const buyBtn = document.createElement('button');
        buyBtn.className = 'store-buy-btn buy';
        buyBtn.textContent = '🪙 Buy';
        buyBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          showConfirmPurchase(item);
        });
        btnRow.appendChild(buyBtn);
      }
    } else if (isEquipped) {
      const btn = document.createElement('button');
      btn.className = 'store-buy-btn equipped';
      btn.textContent = '✓ Active';
      btnRow.appendChild(btn);
    } else {
      // Owned but not equipped
      const tryBtn = document.createElement('button');
      tryBtn.className = 'store-buy-btn equip';
      tryBtn.textContent = '👁 Try';
      tryBtn.style.fontSize = '8px'; tryBtn.style.padding = '4px 8px';
      tryBtn.addEventListener('click', (e) => { e.stopPropagation(); startPreview(item); });
      btnRow.appendChild(tryBtn);

      const btn = document.createElement('button');
      btn.className = 'store-buy-btn equip';
      btn.textContent = 'Equip';
      btn.addEventListener('click', (e) => { e.stopPropagation(); equipItem(item); });
      btnRow.appendChild(btn);
    }

    el.appendChild(btnRow);
    storeGrid.appendChild(el);
  });

  // Animate pattern canvases
  animatePatternPreviews();
}

let patternAnimFrame = null;
function animatePatternPreviews() {
  if (patternAnimFrame) cancelAnimationFrame(patternAnimFrame);

  function tick() {
    const t = performance.now() / 1000;
    for (const { canvas, pattern } of patternCanvases) {
      if (!canvas.isConnected) continue;
      const ctx = canvas.getContext('2d');
      drawPattern(ctx, canvas.width, canvas.height, pattern, t);
    }
    patternAnimFrame = requestAnimationFrame(tick);
  }
  tick();
}

// ── Buy / Equip ──────────────────────────────────────────────

function buyItem(item) {
  if (save.coins < item.price) return;
  if (storeSave.purchased.includes(item.id)) return;

  save.coins -= item.price;
  writeSave(save);

  storeSave.purchased.push(item.id);
  writeStoreSave(storeSave);

  showCoinSplash(-item.price);
  // Clear selection after purchase
  selectedStoreItem = null;
  // Update all coin displays
  if (storeCoins) storeCoins.textContent = save.coins;
  equipItem(item);
}

function equipItem(item) {
  if (item.pattern) {
    storeSave.equippedPattern = item.id;
  } else {
    storeSave.equipped = item.id;
    // If equipping a non-pattern, apply it as the base background
  }
  writeStoreSave(storeSave);
  applyEquippedBackground();
  renderStore();
}

// ── Apply equipped background to game ────────────────────────

function applyEquippedBackground() {
  // Clear any active 3D background
  const bg3D = document.getElementById('bg3DContainer');
  bg3D.innerHTML = '';

  const bgCanvas = document.getElementById('bgCanvas');

  // Find equipped items
  const equippedBase = storeSave.equipped
    ? Object.values(STORE_ITEMS).flat().find(i => i.id === storeSave.equipped)
    : null;
  const equippedPattern = storeSave.equippedPattern
    ? Object.values(STORE_ITEMS).flat().find(i => i.id === storeSave.equippedPattern)
    : null;

  activeBackground = { base: equippedBase, pattern: equippedPattern };

  // Apply solid color
  if (equippedBase?.color) {
    document.body.style.background = equippedBase.color;
    bgCanvas.style.opacity = '0.5';
  } else if (equippedBase?.gradient) {
    document.body.style.background = `linear-gradient(135deg, ${equippedBase.gradient.join(', ')})`;
    bgCanvas.style.opacity = '0.4';
  } else if (equippedBase?.bg3d) {
    document.body.style.background = 'var(--bg)';
    bgCanvas.style.opacity = '0.3';
    spawn3DBackground(equippedBase.bg3d);
  } else {
    document.body.style.background = 'var(--bg)';
    bgCanvas.style.opacity = '1';
  }
}

// ── 3D Background Scenes (simplified canvas-based for performance) ──

function spawn3DBackground(type) {
  const container = document.getElementById('bg3DContainer');
  container.innerHTML = '';
  const c = document.createElement('canvas');
  c.style.width = '100%'; c.style.height = '100%';
  container.appendChild(c);
  const ctx = c.getContext('2d');

  function resize() {
    c.width = window.innerWidth;
    c.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  let mouseX = 0.5, mouseY = 0.5;
  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX / window.innerWidth;
    mouseY = e.clientY / window.innerHeight;
  });

  function loop(time) {
    if (!c.isConnected) return;
    const t = time / 1000;
    const w = c.width, h = c.height;
    ctx.clearRect(0, 0, w, h);

    switch (type) {
      case 'goldenGrid': drawGoldenGrid(ctx, w, h, t, mouseX, mouseY); break;
      case 'starkTerminal': drawStarkTerminal(ctx, w, h, t); break;
      case 'duckiezMatrix': drawDuckiezMatrix(ctx, w, h, t); break;
      case 'warpCore': drawWarpCore(ctx, w, h, t); break;
      case 'liquidGold': drawLiquidGold(ctx, w, h, t); break;
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
}

function drawGoldenGrid(ctx, w, h, t, mx, my) {
  const spacing = 50;
  const ox = (mx - 0.5) * 40;
  const oy = (my - 0.5) * 40;

  ctx.strokeStyle = 'rgba(245,197,24,0.12)';
  ctx.lineWidth = 0.5;

  for (let y = (t * 10) % spacing; y < h; y += spacing) {
    ctx.beginPath(); ctx.moveTo(0, y + oy); ctx.lineTo(w, y + oy); ctx.stroke();
  }
  for (let x = (t * 8) % spacing; x < w; x += spacing) {
    ctx.beginPath(); ctx.moveTo(x + ox, 0); ctx.lineTo(x + ox, h); ctx.stroke();
  }

  // Intersection glow dots
  for (let y = (t * 10) % spacing; y < h; y += spacing) {
    for (let x = (t * 8) % spacing; x < w; x += spacing) {
      ctx.fillStyle = `rgba(245,197,24,${0.1 + Math.sin(t + x * 0.01 + y * 0.01) * 0.08})`;
      ctx.beginPath(); ctx.arc(x + ox, y + oy, 2, 0, Math.PI * 2); ctx.fill();
    }
  }
}

function drawStarkTerminal(ctx, w, h, t) {
  const cx = w / 2, cy = h / 2;
  // Rotating rings
  for (let r = 0; r < 4; r++) {
    const radius = 80 + r * 60;
    ctx.strokeStyle = `rgba(245,197,24,${0.08 + r * 0.03})`;
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(cx, cy, radius, t * (0.3 + r * 0.1), t * (0.3 + r * 0.1) + Math.PI * 1.5); ctx.stroke();
  }
  // Floating particles rising
  for (let i = 0; i < 30; i++) {
    const px = (Math.sin(i * 1.7 + t * 0.3) * 0.5 + 0.5) * w;
    const py = (h - ((t * 30 + i * 50) % h));
    const alpha = 0.1 + Math.sin(t + i) * 0.08;
    ctx.fillStyle = `rgba(245,197,24,${alpha})`;
    ctx.beginPath(); ctx.arc(px, py, 1.5, 0, Math.PI * 2); ctx.fill();
  }
}

function drawDuckiezMatrix(ctx, w, h, t) {
  ctx.font = '12px Orbitron, monospace';
  ctx.fillStyle = 'rgba(245,197,24,0.15)';
  const cols = Math.ceil(w / 14);
  for (let c = 0; c < cols; c++) {
    const speed = 20 + (c % 7) * 8;
    const yOff = (t * speed + c * 37) % (h + 200) - 100;
    for (let r = 0; r < 8; r++) {
      const y = yOff + r * 16;
      if (y < -16 || y > h + 16) continue;
      const alpha = Math.max(0, 0.25 - r * 0.03);
      ctx.globalAlpha = alpha;
      ctx.fillText('D', c * 14, y);
    }
  }
  ctx.globalAlpha = 1;
}

function drawWarpCore(ctx, w, h, t) {
  const cx = w / 2, cy = h / 2;
  // Pulsing core
  const pulse = Math.sin(t * 2) * 0.3 + 0.7;
  const grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 80 * pulse);
  grd.addColorStop(0, `rgba(245,197,24,${0.15 * pulse})`);
  grd.addColorStop(1, 'transparent');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, w, h);

  // Stars
  for (let i = 0; i < 80; i++) {
    const angle = (i / 80) * Math.PI * 2 + t * 0.1;
    const dist = 60 + ((t * 15 + i * 12) % 400);
    const px = cx + Math.cos(angle) * dist;
    const py = cy + Math.sin(angle) * dist;
    if (px < 0 || px > w || py < 0 || py > h) continue;
    const alpha = Math.max(0, 0.3 - dist / 500);
    ctx.fillStyle = `rgba(245,197,24,${alpha})`;
    ctx.beginPath(); ctx.arc(px, py, 1, 0, Math.PI * 2); ctx.fill();
  }
}

function drawLiquidGold(ctx, w, h, t) {
  ctx.strokeStyle = 'rgba(245,197,24,0.08)';
  ctx.lineWidth = 0.5;
  for (let y = 0; y < h; y += 8) {
    ctx.beginPath();
    for (let x = 0; x <= w; x += 4) {
      const wave = Math.sin(x * 0.01 + t + y * 0.02) * 10 +
                   Math.sin(x * 0.02 - t * 1.3 + y * 0.01) * 6;
      ctx.lineTo(x, y + wave);
    }
    ctx.stroke();
  }
}

// ═══════════════════════════════════════════════════════════════
// "Try Before You Buy" — 5-Second Preview Mode
// ═══════════════════════════════════════════════════════════════

function startPreview(item) {
  // Cancel any existing preview
  endPreview(true);

  // Save current body background so we can restore it
  const prevBodyBg = document.body.style.background;
  const prevCanvasOpacity = document.getElementById('bgCanvas').style.opacity;
  const prevBg3DContent = document.getElementById('bg3DContainer').innerHTML;

  // Build fullscreen overlay with countdown
  previewOverlay = document.createElement('div');
  previewOverlay.id = 'previewOverlay';
  Object.assign(previewOverlay.style, {
    position: 'fixed', inset: '0', zIndex: '15',
    display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'flex-end',
    paddingBottom: '40px', pointerEvents: 'none',
  });

  // Top bar with item name + countdown
  const topBar = document.createElement('div');
  Object.assign(topBar.style, {
    position: 'absolute', top: '16px', left: '50%', transform: 'translateX(-50%)',
    background: 'rgba(6,8,15,0.85)', border: '1px solid rgba(245,197,24,0.25)',
    borderRadius: '8px', padding: '10px 24px', backdropFilter: 'blur(10px)',
    display: 'flex', alignItems: 'center', gap: '16px', pointerEvents: 'auto',
  });

  const label = document.createElement('span');
  label.style.fontFamily = "'Orbitron',sans-serif";
  label.style.fontSize = '12px'; label.style.fontWeight = '700';
  label.style.letterSpacing = '2px'; label.style.color = 'var(--gold)';
  label.style.textTransform = 'uppercase';
  label.textContent = `Previewing: ${item.name}`;
  topBar.appendChild(label);

  const countdown = document.createElement('span');
  countdown.id = 'previewCountdown';
  countdown.style.fontFamily = "'Share Tech Mono',monospace";
  countdown.style.fontSize = '14px'; countdown.style.color = 'var(--cyan)';
  countdown.style.minWidth = '24px'; countdown.style.textAlign = 'center';
  countdown.textContent = '5s';
  topBar.appendChild(countdown);

  // Close early button
  const closeBtn = document.createElement('button');
  closeBtn.textContent = '✕';
  Object.assign(closeBtn.style, {
    background: 'transparent', border: '1px solid rgba(255,255,255,0.15)',
    color: '#fff', borderRadius: '4px', width: '28px', height: '28px',
    cursor: 'pointer', fontFamily: "'Rajdhani',sans-serif", fontSize: '14px',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    pointerEvents: 'auto', transition: 'all 0.2s',
  });
  closeBtn.addEventListener('mouseenter', () => { closeBtn.style.borderColor = 'var(--gold)'; closeBtn.style.color = 'var(--gold)'; });
  closeBtn.addEventListener('mouseleave', () => { closeBtn.style.borderColor = 'rgba(255,255,255,0.15)'; closeBtn.style.color = '#fff'; });
  closeBtn.addEventListener('click', () => endPreview(false));
  topBar.appendChild(closeBtn);

  previewOverlay.appendChild(topBar);

  // Progress bar at bottom
  const progressWrap = document.createElement('div');
  Object.assign(progressWrap.style, {
    position: 'absolute', bottom: '0', left: '0', right: '0', height: '3px',
    background: 'rgba(255,255,255,0.04)',
  });
  const progressFill = document.createElement('div');
  progressFill.id = 'previewProgress';
  Object.assign(progressFill.style, {
    height: '100%', width: '100%',
    background: 'linear-gradient(90deg, var(--gold), var(--cyan))',
    transition: 'width 1s linear',
  });
  progressWrap.appendChild(progressFill);
  previewOverlay.appendChild(progressWrap);

  document.body.appendChild(previewOverlay);

  // Apply the item as a temporary background
  applyPreviewBackground(item);

  // Start 5-second countdown
  previewCountdown = 5;
  countdown.textContent = '5s';

  // Animate progress bar shrinking
  requestAnimationFrame(() => {
    progressFill.style.width = '0%';
    progressFill.style.transition = 'width 5s linear';
  });

  previewTimer = setInterval(() => {
    previewCountdown--;
    const cd = document.getElementById('previewCountdown');
    if (cd) cd.textContent = previewCountdown + 's';

    if (previewCountdown <= 0) {
      endPreview(false);
    }
  }, 1000);

  // Store restore data on the overlay element
  previewOverlay._restore = {
    bodyBg: prevBodyBg,
    canvasOpacity: prevCanvasOpacity,
    bg3DContent: prevBg3DContent,
  };
}

function applyPreviewBackground(item) {
  const bg3D = document.getElementById('bg3DContainer');
  const bgCanvas = document.getElementById('bgCanvas');

  bg3D.innerHTML = '';

  if (item.color) {
    document.body.style.background = item.color;
    bgCanvas.style.opacity = '0.5';
  } else if (item.gradient) {
    document.body.style.background = `linear-gradient(135deg, ${item.gradient.join(', ')})`;
    bgCanvas.style.opacity = '0.4';
  } else if (item.bg3d) {
    document.body.style.background = 'var(--bg)';
    bgCanvas.style.opacity = '0.3';
    spawn3DBackground(item.bg3d);
  } else if (item.pattern) {
    document.body.style.background = 'var(--bg)';
    bgCanvas.style.opacity = '0.4';
    // Show pattern on the bg3D container as a full-screen canvas overlay
    const c = document.createElement('canvas');
    c.style.width = '100%'; c.style.height = '100%';
    bg3D.appendChild(c);
    c.width = window.innerWidth;
    c.height = window.innerHeight;

    function animatePreviewPattern(time) {
      if (!c.isConnected) return;
      const ctx = c.getContext('2d');
      drawPattern(ctx, c.width, c.height, item.pattern, time / 1000);
      requestAnimationFrame(animatePreviewPattern);
    }
    requestAnimationFrame(animatePreviewPattern);
  }
}

function endPreview(silent) {
  if (previewTimer) {
    clearInterval(previewTimer);
    previewTimer = null;
  }

  const overlay = document.getElementById('previewOverlay');
  if (overlay) {
    // Restore the previous background
    const restore = overlay._restore;
    if (restore) {
      document.body.style.background = restore.bodyBg || 'var(--bg)';
      document.getElementById('bgCanvas').style.opacity = restore.canvasOpacity || '1';
      document.getElementById('bg3DContainer').innerHTML = restore.bg3DContent || '';
    }
    overlay.remove();
  }

  previewOverlay = null;
  previewCountdown = 0;

  // Re-apply the actual equipped background
  if (!silent) {
    applyEquippedBackground();
  }
}

// ── Store navigation ─────────────────────────────────────────

function showStore() {
  hideAll();
  selectedStoreItem = null;
  storeScreen.classList.add('active');
  renderStore();
}

openStoreBtn.addEventListener('click', () => showStore());
storeBackBtn.addEventListener('click', () => {
  selectedStoreItem = null;
  endPreview(true);
  if (patternAnimFrame) cancelAnimationFrame(patternAnimFrame);
  patternCanvases = [];
  applyEquippedBackground();
  showLevelSelect();
});

// Apply equipped bg on load
applyEquippedBackground();

// ═══════════════════════════════════════════════════════════════
// Promo Code System
// ═══════════════════════════════════════════════════════════════

const PROMO_CODES = {
  'WELCOME': {
    coins: 67,
    randomBasicBg: true, // gives 1 random basic background
    description: 'Welcome Gift',
  },
};

const promoCodeBtn = document.getElementById('promoCodeBtn');
const promoModal = document.getElementById('promoModal');
const promoCloseBtn = document.getElementById('promoCloseBtn');
const promoInput = document.getElementById('promoInput');
const promoRedeemBtn = document.getElementById('promoRedeemBtn');
const promoMsg = document.getElementById('promoMsg');
const promoRewardOverlay = document.getElementById('promoRewardOverlay');
const promoRewardBox = document.getElementById('promoRewardBox');
const promoRewardDetails = document.getElementById('promoRewardDetails');
const promoRewardCloseBtn = document.getElementById('promoRewardCloseBtn');

function openPromoModal() {
  promoModal.style.display = 'flex';
  promoInput.value = '';
  promoMsg.textContent = '';
  promoMsg.style.color = '';
  setTimeout(() => promoInput.focus(), 100);
}

function closePromoModal() {
  promoModal.style.display = 'none';
  promoInput.value = '';
  promoMsg.textContent = '';
}

function showPromoError(msg) {
  promoMsg.style.color = '#E74C3C';
  promoMsg.textContent = msg;
  // Shake the input
  promoInput.style.animation = 'none';
  promoInput.offsetHeight; // reflow
  promoInput.style.animation = 'promoShake 0.4s ease';
}

function redeemPromoCode() {
  const raw = promoInput.value.trim().toUpperCase();
  if (!raw) {
    showPromoError('Please enter a code');
    return;
  }

  const reward = PROMO_CODES[raw];
  if (!reward) {
    showPromoError('Invalid code — check spelling');
    return;
  }

  // Check if already used
  if (save.usedCodes.includes(raw)) {
    showPromoError('You already redeemed this code!');
    return;
  }

  // ── Redeem the code ──
  save.usedCodes.push(raw);

  // Award coins
  const coinsAwarded = reward.coins || 0;
  save.coins += coinsAwarded;

  // Award random basic background (if not already owned)
  let awardedBgName = null;
  if (reward.randomBasicBg) {
    const basicItems = STORE_ITEMS.basic;
    const unowned = basicItems.filter(item => !storeSave.purchased.includes(item.id));
    if (unowned.length > 0) {
      const pick = unowned[Math.floor(Math.random() * unowned.length)];
      storeSave.purchased.push(pick.id);
      writeStoreSave(storeSave);
      awardedBgName = pick.name;
    } else {
      // All basics owned — give extra 20 coins instead
      save.coins += 20;
      awardedBgName = '(all owned — +20 bonus coins!)';
    }
  }

  writeSave(save);
  updateAllCoinDisplays();

  // Close modal, show reward reveal
  closePromoModal();
  showPromoReward(coinsAwarded, awardedBgName);
}

function showPromoReward(coins, bgName) {
  promoRewardOverlay.style.display = 'flex';
  promoRewardBox.style.transform = 'scale(0.5)';
  promoRewardBox.style.opacity = '0';

  let detailsHTML = '';
  detailsHTML += `<div style="margin-bottom:6px">🪙 <span style="color:var(--gold);font-weight:700;font-size:20px">+${coins}</span> Coins</div>`;
  if (bgName) {
    detailsHTML += `<div>🎨 <span style="color:#4da6ff;font-weight:600">Basic Background:</span> ${bgName}</div>`;
  }
  promoRewardDetails.innerHTML = detailsHTML;

  // Trigger entry animation
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      promoRewardBox.style.transform = 'scale(1)';
      promoRewardBox.style.opacity = '1';
    });
  });

  // Spawn some confetti particles
  spawnPromoConfetti();
}

function closePromoReward() {
  promoRewardBox.style.transform = 'scale(0.8)';
  promoRewardBox.style.opacity = '0';
  setTimeout(() => {
    promoRewardOverlay.style.display = 'none';
    // Refresh level select to show updated coins
    if (levelSelectScreen.classList.contains('active')) showLevelSelect();
  }, 300);
}

function spawnPromoConfetti() {
  const colors = ['#FFD700', '#007BFF', '#2ECC71', '#E74C3C', '#c77dff', '#4da6ff'];
  const container = promoRewardOverlay;
  for (let i = 0; i < 40; i++) {
    const p = document.createElement('div');
    const size = 4 + Math.random() * 8;
    const color = colors[Math.floor(Math.random() * colors.length)];
    const left = 10 + Math.random() * 80;
    const delay = Math.random() * 0.5;
    const duration = 1.2 + Math.random() * 1.5;
    const rotation = Math.random() * 720 - 360;
    Object.assign(p.style, {
      position: 'fixed',
      left: left + '%',
      top: '-5%',
      width: size + 'px',
      height: size + 'px',
      background: color,
      borderRadius: Math.random() > 0.5 ? '50%' : '2px',
      pointerEvents: 'none',
      zIndex: '10001',
      opacity: '1',
      animation: `promoConfettiFall ${duration}s ease-in ${delay}s forwards`,
      transform: `rotate(${rotation}deg)`,
    });
    container.appendChild(p);
    // Cleanup after animation
    setTimeout(() => p.remove(), (delay + duration) * 1000 + 100);
  }
}

function updateAllCoinDisplays() {
  const displays = [
    document.getElementById('startCoins'),
    document.getElementById('selectCoins'),
    document.getElementById('hudCoins'),
    document.getElementById('storeCoins'),
  ];
  displays.forEach(el => { if (el) el.textContent = save.coins; });
}

// Promo event listeners
promoCodeBtn.addEventListener('click', openPromoModal);
promoCloseBtn.addEventListener('click', closePromoModal);
promoRedeemBtn.addEventListener('click', redeemPromoCode);
promoRewardCloseBtn.addEventListener('click', closePromoReward);

// Close modal on background click
promoModal.addEventListener('click', (e) => {
  if (e.target === promoModal) closePromoModal();
});
promoRewardOverlay.addEventListener('click', (e) => {
  if (e.target === promoRewardOverlay) closePromoReward();
});

// Enter key to redeem
promoInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') redeemPromoCode();
});

// ── Electric Lightning Title Effect ──────────────────────────
(function initLightning() {
  const canvas = document.getElementById('lightningCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const wrap = document.getElementById('electricTitleWrap');
  const titleEl = document.getElementById('electricTitleText');
  const letters = titleEl.querySelectorAll('.eletter');
  let cW, cH;

  function resize() {
    const rect = wrap.getBoundingClientRect();
    cW = canvas.width = rect.width * window.devicePixelRatio;
    cH = canvas.height = rect.height * window.devicePixelRatio;
    ctx.setTransform(window.devicePixelRatio, 0, 0, window.devicePixelRatio, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);

  // ── Glow sweep: D,I,T,C,H (skip THE) then D,U,C,K ──
  // Letters: indices 0-4 = DITCH, 5-7 = THE (skip), 8-11 = DUCK
  const sweepOrder = [0,1,2,3,4, 8,9,10,11]; // skip THE (5,6,7)
  let sweepIdx = 0;
  let sweepTimer = 0;
  const sweepInterval = 120; // ms per letter
  const glowDuration = 350; // ms each letter stays lit
  let letterGlows = new Array(12).fill(0); // timestamp when lit

  function tickSweep(now) {
    if (now > sweepTimer) {
      const li = sweepOrder[sweepIdx];
      letterGlows[li] = now;
      sweepIdx = (sweepIdx + 1) % sweepOrder.length;
      sweepTimer = now + sweepInterval;
    }
    for (let i = 0; i < letters.length; i++) {
      const age = now - letterGlows[i];
      if (letterGlows[i] > 0 && age < glowDuration) {
        letters[i].classList.add('glow-active');
      } else {
        letters[i].classList.remove('glow-active');
      }
    }
  }

  // ── Edge-only lightning bolts ──
  // Get letter bounding boxes relative to wrap
  function getLetterRects() {
    const wrapRect = wrap.getBoundingClientRect();
    const rects = [];
    letters.forEach(l => {
      const r = l.getBoundingClientRect();
      rects.push({
        x: r.left - wrapRect.left,
        y: r.top - wrapRect.top,
        w: r.width,
        h: r.height
      });
    });
    return rects;
  }

  // Sample a random point along the edge of a letter rect
  function edgePoint(rect) {
    const perim = 2 * (rect.w + rect.h);
    let p = Math.random() * perim;
    if (p < rect.w) return { x: rect.x + p, y: rect.y }; // top
    p -= rect.w;
    if (p < rect.h) return { x: rect.x + rect.w, y: rect.y + p }; // right
    p -= rect.h;
    if (p < rect.w) return { x: rect.x + rect.w - p, y: rect.y + rect.h }; // bottom
    p -= rect.w;
    return { x: rect.x, y: rect.y + rect.h - p }; // left
  }

  function createBolt(x1, y1, x2, y2, depth) {
    const segs = [];
    const dx = x2 - x1, dy = y2 - y1;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 2 || depth > 4) {
      segs.push({ x1, y1, x2, y2, a: Math.max(0.2, 1 - depth * 0.2) });
      return segs;
    }
    const jitter = dist * (0.3 - depth * 0.04);
    const mx = (x1 + x2) / 2 + (Math.random() - 0.5) * jitter;
    const my = (y1 + y2) / 2 + (Math.random() - 0.5) * jitter;
    segs.push(...createBolt(x1, y1, mx, my, depth + 1));
    segs.push(...createBolt(mx, my, x2, y2, depth + 1));
    if (depth < 2 && Math.random() < 0.3) {
      const ang = Math.atan2(y2 - y1, x2 - x1) + (Math.random() - 0.5) * 1.5;
      const fl = dist * (0.15 + Math.random() * 0.2);
      segs.push(...createBolt(mx, my, mx + Math.cos(ang) * fl, my + Math.sin(ang) * fl, depth + 2));
    }
    return segs;
  }

  let bolts = [];
  let nextBolt = 0;

  function spawnEdgeBolt() {
    const rects = getLetterRects();
    if (rects.length === 0) return;
    // Pick a random letter edge as start
    const ri1 = Math.floor(Math.random() * rects.length);
    const p1 = edgePoint(rects[ri1]);
    // End at a nearby letter edge or same letter opposite side
    let ri2 = ri1;
    if (Math.random() < 0.6 && rects.length > 1) {
      // Jump to an adjacent letter
      ri2 = ri1 + (Math.random() < 0.5 ? -1 : 1);
      ri2 = Math.max(0, Math.min(rects.length - 1, ri2));
    }
    const p2 = edgePoint(rects[ri2]);
    const segs = createBolt(p1.x, p1.y, p2.x, p2.y, 0);
    bolts.push({ segs, birth: performance.now(), life: 80 + Math.random() * 150 });
  }

  function drawFrame(now) {
    const rw = wrap.getBoundingClientRect().width;
    const rh = wrap.getBoundingClientRect().height;
    ctx.clearRect(0, 0, rw, rh);

    // Tick letter glow sweep
    tickSweep(now);

    // Spawn edge bolts
    if (now > nextBolt) {
      if (Math.random() < 0.2) {
        // Burst: 2-3 simultaneous
        for (let i = 0; i < 2 + Math.floor(Math.random() * 2); i++) spawnEdgeBolt();
        nextBolt = now + 60 + Math.random() * 200;
      } else {
        spawnEdgeBolt();
        nextBolt = now + 100 + Math.random() * 400;
      }
    }

    // Draw bolts
    for (let i = bolts.length - 1; i >= 0; i--) {
      const b = bolts[i];
      const age = now - b.birth;
      if (age > b.life) { bolts.splice(i, 1); continue; }
      const prog = age / b.life;
      const fade = prog < 0.2 ? prog / 0.2 : 1 - ((prog - 0.2) / 0.8);

      for (const s of b.segs) {
        const alpha = fade * s.a;
        if (alpha < 0.01) continue;
        // Outer glow (gold)
        ctx.beginPath();
        ctx.moveTo(s.x1, s.y1); ctx.lineTo(s.x2, s.y2);
        ctx.strokeStyle = `rgba(255,215,0,${alpha * 0.3})`;
        ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.stroke();
        // Core
        ctx.beginPath();
        ctx.moveTo(s.x1, s.y1); ctx.lineTo(s.x2, s.y2);
        ctx.strokeStyle = `rgba(255,230,100,${alpha * 0.7})`;
        ctx.lineWidth = 2; ctx.stroke();
        // White hot center
        ctx.beginPath();
        ctx.moveTo(s.x1, s.y1); ctx.lineTo(s.x2, s.y2);
        ctx.strokeStyle = `rgba(255,255,240,${alpha * 0.95})`;
        ctx.lineWidth = 0.8; ctx.stroke();
      }
    }
  }

  function tick() {
    drawFrame(performance.now());
    requestAnimationFrame(tick);
  }
  tick();
})();

// ── Init ─────────────────────────────────────────────────────
processHeartRecovery();
showStartScreen();


// ═══════════════════════════════════════════════════════════════
// Background Particle Canvas
// ═══════════════════════════════════════════════════════════════

const canvas = document.getElementById('bgCanvas');
const ctx = canvas.getContext('2d');
let W, H;
let particles = [];
let glowColor = 'rgba(245,197,24,0.06)';
let glowIntensity = 0;

function resize() {
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
  initParticles();
}

function initParticles() {
  particles = [];
  const count = Math.floor((W * H) / 14000);
  for (let i = 0; i < count; i++) {
    particles.push({
      x: Math.random() * W,
      y: Math.random() * H,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      r: Math.random() * 1.5 + 0.5,
      a: Math.random() * 0.3 + 0.05,
    });
  }
}

function triggerGlowPulse(type) {
  if (type === 'gold') glowColor = 'rgba(245,197,24,0.08)';
  else if (type === 'red') glowColor = 'rgba(255,61,90,0.08)';
  glowIntensity = 1;
}

function drawBg(time) {
  ctx.clearRect(0, 0, W, H);

  // If a pattern background is equipped, draw it and skip default particles
  const equippedPatternItem = activeBackground?.pattern;
  if (equippedPatternItem?.pattern) {
    drawPattern(ctx, W, H, equippedPatternItem.pattern, time / 1000);
    // Still apply glow pulse on top of the pattern
    if (glowIntensity > 0) {
      ctx.fillStyle = glowColor;
      ctx.globalAlpha = glowIntensity * 0.5;
      ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = 1;
      glowIntensity *= 0.96;
      if (glowIntensity < 0.01) glowIntensity = 0;
    }
    requestAnimationFrame(drawBg);
    return;
  }

  if (glowIntensity > 0) {
    ctx.fillStyle = glowColor;
    ctx.globalAlpha = glowIntensity * 0.5;
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = 1;
    glowIntensity *= 0.96;
    if (glowIntensity < 0.01) glowIntensity = 0;
  }

  ctx.strokeStyle = 'rgba(245,197,24,0.015)';
  ctx.lineWidth = 1;
  const spacing = 60;
  const offset = (time * 0.01) % spacing;
  for (let y = -spacing + offset; y < H + spacing; y += spacing) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }
  for (let x = -spacing + offset * 0.7; x < W + spacing; x += spacing) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }

  for (const p of particles) {
    p.x += p.vx;
    p.y += p.vy;
    if (p.x < 0) p.x = W;
    if (p.x > W) p.x = 0;
    if (p.y < 0) p.y = H;
    if (p.y > H) p.y = 0;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(245,197,24,${p.a})`;
    ctx.fill();
  }

  ctx.strokeStyle = 'rgba(245,197,24,0.03)';
  ctx.lineWidth = 0.5;
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      const dx = particles[i].x - particles[j].x;
      const dy = particles[i].y - particles[j].y;
      const dist = dx * dx + dy * dy;
      if (dist < 8000) {
        ctx.beginPath();
        ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(particles[j].x, particles[j].y);
        ctx.stroke();
      }
    }
  }

  const grd = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.5);
  grd.addColorStop(0, 'rgba(245,197,24,0.02)');
  grd.addColorStop(1, 'transparent');
  ctx.fillStyle = grd;
  ctx.fillRect(0, 0, W, H);

  requestAnimationFrame(drawBg);
}

window.addEventListener('resize', resize);
resize();
requestAnimationFrame(drawBg);